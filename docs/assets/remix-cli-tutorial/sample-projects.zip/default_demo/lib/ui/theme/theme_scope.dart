import 'package:flutter/widgets.dart';
import 'package:remix/remix.dart';

import 'theme_data.dart';

/// Installs a [AcmeThemeData] for a subtree.
///
/// Two things are installed together on purpose:
///
/// * [AcmeTheme], so application code can read the raw values through
///   [AcmeTheme.of];
/// * a `MixScope` carrying the same values keyed by `AcmeTokens`, so every Mix
///   styler resolved below this point sees them.
///
/// Each supplied theme replaces the values for its appearance. An empty nested
/// scope inherits the parent pair and selection; individual tokens do not merge.
class AcmeThemeScope extends StatelessWidget {
  /// A root follows the system and supplies both preset defaults.
  /// A custom theme without darkTheme is used in both modes.
  /// Nested scopes inherit the configured pair and active selection.
  const AcmeThemeScope({
    super.key,
    this.theme,
    this.darkTheme,
    this.mode,
    this.data,
    required this.child,
  }) : assert(
         data == null || (theme == null && darkTheme == null && mode == null),
         'Use data for a fixed theme, or theme/darkTheme/mode for appearance selection.',
       );

  final AcmeThemeData? theme;
  final AcmeThemeData? darkTheme;
  final AcmeThemeMode? mode;

  /// Compatibility shorthand for installing one fixed, resolved theme.
  final AcmeThemeData? data;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final view = View.maybeOf(context);
    if (MediaQuery.maybeOf(context) == null && view != null) {
      return MediaQuery.fromView(
        view: view,
        child: Builder(builder: _build),
      );
    }
    return _build(context);
  }

  Widget _build(BuildContext context) {
    final inherited = context.dependOnInheritedWidgetOfExactType<AcmeTheme>();
    final base =
        data ??
        theme ??
        inherited?.baseTheme ??
        inherited?.data ??
        const AcmeThemeData.light();
    final dark =
        data ??
        darkTheme ??
        (theme != null
            ? theme!
            : inherited?.darkTheme ??
                  inherited?.data ??
                  const AcmeThemeData.dark());
    final useDark = data != null
        ? data!.brightness == Brightness.dark
        : mode == null && inherited != null
        ? inherited.usesDarkTheme
        : switch (mode ?? AcmeThemeMode.system) {
            AcmeThemeMode.light => false,
            AcmeThemeMode.dark => true,
            AcmeThemeMode.system =>
              (MediaQuery.maybePlatformBrightnessOf(context) ??
                      Brightness.light) ==
                  Brightness.dark,
          };
    final selected = useDark ? dark : base;
    return AcmeTheme(
      data: selected,
      baseTheme: base,
      darkTheme: dark,
      useDarkTheme: useDark,
      child: MixScope(tokens: selected.tokens, child: child),
    );
  }
}

/// The inherited half of [AcmeThemeScope].
///
/// Prefer [AcmeThemeScope]; this is public because `AcmeTheme.of` is how widgets
/// read theme values that are not expressed as Mix styles, and because
/// `InheritedTheme.wrap` has to be able to rebuild it across a route
/// boundary.
class AcmeTheme extends InheritedTheme {
  /// Creates the inherited theme holding [data].
  const AcmeTheme({
    super.key,
    required this.data,
    this.baseTheme,
    this.darkTheme,
    this.useDarkTheme,
    required super.child,
  });

  /// The theme values available to [child].
  final AcmeThemeData data;
  final AcmeThemeData? baseTheme;
  final AcmeThemeData? darkTheme;
  final bool? useDarkTheme;
  bool get usesDarkTheme => useDarkTheme ?? data.brightness == Brightness.dark;

  /// The closest [AcmeThemeData], or `null` when no scope is installed.
  static AcmeThemeData? maybeOf(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AcmeTheme>()?.data;

  /// The closest [AcmeThemeData].
  ///
  /// Throws when no [AcmeThemeScope] is installed above [context]; use
  /// [maybeOf] when absence is a valid state.
  static AcmeThemeData of(BuildContext context) {
    final data = maybeOf(context);
    if (data != null) return data;

    throw FlutterError.fromParts([
      ErrorSummary('No AcmeTheme found.'),
      ErrorDescription(
        '${context.widget.runtimeType} tried to read the UI theme, but no '
        'AcmeThemeScope was found above it.',
      ),
      context.describeElement('The context used was'),
    ]);
  }

  /// Rebuilds the theme *and* its Mix scope for a captured subtree.
  ///
  /// `InheritedTheme.capture` only carries `InheritedTheme`s across a route
  /// boundary. `MixScope` is a plain `InheritedModel`, so without rebuilding
  /// it here a captured subtree would keep the theme values and lose the
  /// token values that recipes actually resolve.
  @override
  Widget wrap(BuildContext context, Widget child) {
    return AcmeTheme(
      data: data,
      baseTheme: baseTheme,
      darkTheme: darkTheme,
      useDarkTheme: useDarkTheme,
      child: MixScope(tokens: data.tokens, child: child),
    );
  }

  @override
  bool updateShouldNotify(AcmeTheme oldWidget) =>
      data != oldWidget.data ||
      baseTheme != oldWidget.baseTheme ||
      darkTheme != oldWidget.darkTheme ||
      useDarkTheme != oldWidget.useDarkTheme;
}
