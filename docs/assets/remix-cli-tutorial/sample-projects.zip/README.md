# Remix CLI tutorial samples

The default and Fortal projects contain the final tutorial source, generated adapters, and four behavior tests each.
The application name Launchpad is fictional. Its callbacks use local state and send no requests.

## Run a sample

1. Use Flutter 3.44.0 and Dart 3.12.0.
2. Use the complete Remix checkout at bfae6507676fadea7632e2f7f66924935c04ca2a.
3. Open default_demo or fortal_demo.
4. Replace /path/to/remix in pubspec.yaml and pubspec_overrides.yaml with your checkout path.
5. Run flutter pub get from the sample directory.
6. Run flutter analyze, flutter test, and flutter run -d chrome.

Pub refreshes the recorded path in the lockfile after you update the dependency paths.
The archive retains hosted dependency versions in pubspec.lock.
The archive excludes package caches and build outputs.

## Inspect the source

- lib/main.dart: SampleApp creates the host and theme scope. WorkspacePage owns the screen and callbacks.
- lib/ui/components/button.dart: The default _metricsFor table contains the demonstrated 44-pixel medium height.
- lib/ui/: The CLI installed the authored recipes and generated the adapters.
- remix.yaml: The configuration selects the preset and Acme prefix.
- test/workflow_test.dart: Four tests cover form state, loading, disabled controls, instance callbacks, dialogs, and Sidebar.

The default 44-pixel recipe change does not apply to the Fortal project.
The HTML tutorial includes the complete first-render source and both final main.dart files.

## Review source preservation

Run dart run remix_cli:remix add button --diff to compare your source with the bundled template.
Run dart run remix_cli:remix add button to verify that ordinary add preserves your source.
An explicit --overwrite replaces the requested recipe. Save your edit before that experiment.

After a recipe API change, run dart run build_runner build --delete-conflicting-outputs.
