import 'package:flutter/widgets.dart';
import 'package:remix/remix.dart';

import 'theme_data.dart';
import 'tokens.dart';

/// Establishes a courtesy default text run for bare [Text] descendants.
///
/// `.radix-themes` is not only a token carrier upstream: `color.css` sets
/// `color: var(--gray-12)` in the same rule as the `data-has-background` fill,
/// and `typography.css` pins the root to `--default-font-size`
/// (`--font-size-3`), `--default-line-height`, `--default-letter-spacing`, and
/// `--default-font-weight`. Those resolve to exactly [AcmeTokens.text3] plus
/// [AcmeTokens.gray12] at regular weight.
///
/// Acme text recipes resolve and pin their own runs. This fallback keeps
/// deliberately bare [Text] descendants aligned with Radix's root typography
/// and neutral foreground. A nearer descendant `DefaultTextStyle` still wins
/// through Flutter's normal inheritance.
///
/// Only the outermost [AcmeScope] installs this. A nested scope re-scopes
/// tokens for its subtree and nothing more: upstream, `.radix-themes` inside
/// another `.radix-themes` still inherits `color` and the font properties from
/// its parent chain, and a nested scope that reinstalled the root run here
/// would silently replace whatever `DefaultTextStyle` the subtree sits in.
///
/// The font family is deliberately left unset. Radix's `--default-font-family`
/// is the platform system stack, and a null family is Flutter's equivalent;
/// naming a concrete family here would pin every consumer to one typeface.
Widget _acmeRootTextStyle({
  required Map<MixToken<Object?>, Object> tokens,
  required Widget child,
}) {
  final root = tokens[AcmeTokens.text3]! as TextStyle;

  return DefaultTextStyle(
    style: root.copyWith(
      color: tokens[AcmeTokens.gray12]! as Color,
      fontWeight: tokens[AcmeTokens.fontWeightRegular]! as FontWeight,
    ),
    child: child,
  );
}

/// Widget that provides Acme design tokens to its subtree via [MixScope].
///
/// Use [AcmeScope] at the root of your app (or around any subtree that uses
/// Acme styles) so that [AcmeTokens] resolve to actual values.
///
/// ```dart
/// AcmeScope(
///   child: WidgetsApp(...),
/// )
/// ```
class AcmeScope extends StatelessWidget {
  const AcmeScope({
    super.key,
    this.accent,
    this.gray,
    this.brightness,
    this.panelBackground,
    this.radius,
    this.scaling,
    this.hasBackground,
    this.orderOfModifiers,
    required this.child,
  });

  final AcmeAccentColor? accent;
  final AcmeGrayColor? gray;
  final Brightness? brightness;
  final AcmePanelBackground? panelBackground;
  final AcmeRadius? radius;
  final AcmeScaling? scaling;
  final bool? hasBackground;
  final List<Type>? orderOfModifiers;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final config = AcmeThemeConfig(
      accent: accent,
      gray: gray,
      brightness: brightness,
      panelBackground: panelBackground,
      radius: radius,
      scaling: scaling,
      hasBackground: hasBackground,
    );
    final parent = AcmeTheme.maybeOf(context);
    final data = _resolveAcmeTheme(config, parent: parent);
    final tokens = buildAcmeScopeTokens(data);
    Widget result = MixScope(
      tokens: tokens,
      orderOfModifiers: orderOfModifiers,
      // Theme-root identity, not `hasBackground`, decides who owns the text
      // run: a scope nested for its accent or scaling must leave the current
      // run alone, while a root scope with `hasBackground: false` still
      // establishes it.
      child: parent == null
          ? _acmeRootTextStyle(tokens: tokens, child: child)
          : child,
    );
    if (data.hasBackground) {
      result = ColoredBox(
        color: tokens[AcmeTokens.colorBackground]! as Color,
        child: result,
      );
    }

    return AcmeTheme(
      data: data,
      orderOfModifiers: orderOfModifiers,
      child: result,
    );
  }
}

AcmeThemeData _resolveAcmeTheme(
  AcmeThemeConfig config, {
  AcmeThemeData? parent,
}) {
  final accent = config.accent ?? parent?.accent ?? AcmeAccentColor.indigo;

  return AcmeThemeData(
    accent: accent,
    gray: config.gray ?? parent?.gray ?? AcmeGrayColor.slate,
    brightness: config.brightness ?? parent?.brightness ?? Brightness.light,
    panelBackground:
        config.panelBackground ??
        parent?.panelBackground ??
        AcmePanelBackground.translucent,
    radius: config.radius ?? parent?.radius ?? AcmeRadius.medium,
    scaling: config.scaling ?? parent?.scaling ?? AcmeScaling.percent100,
    hasBackground: config.hasBackground ?? parent == null,
  );
}

/// Makes the active [AcmeThemeData] available to descendants.
class AcmeTheme extends InheritedTheme {
  const AcmeTheme({
    super.key,
    required this.data,
    this.orderOfModifiers,
    required super.child,
  });

  final AcmeThemeData data;
  final List<Type>? orderOfModifiers;

  /// Returns the closest resolved Acme theme.
  static AcmeThemeData of(BuildContext context) {
    final data = maybeOf(context);
    if (data != null) return data;
    throw FlutterError.fromParts([
      ErrorSummary('No AcmeTheme found.'),
      ErrorDescription(
        '${context.widget.runtimeType} tried to read the Acme theme, but no AcmeScope was found above it.',
      ),
      context.describeElement('The context used was'),
    ]);
  }

  /// Returns the closest resolved Acme theme, if one is available.
  static AcmeThemeData? maybeOf(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AcmeTheme>()?.data;

  /// Rebuilds only the theme and its Mix tokens.
  ///
  /// The captured subtree's text run is *not* synthesized here.
  /// `DefaultTextStyle` is itself an [InheritedTheme], so
  /// `InheritedTheme.capture` already carries the actual nearest ambient run
  /// across to the new route; installing the Radix root run alongside it would
  /// overwrite that capture with a value the source context never had.
  @override
  Widget wrap(BuildContext context, Widget child) => AcmeTheme(
    data: data,
    orderOfModifiers: orderOfModifiers,
    child: MixScope(
      tokens: buildAcmeScopeTokens(data),
      orderOfModifiers: orderOfModifiers,
      child: child,
    ),
  );

  @override
  bool updateShouldNotify(AcmeTheme oldWidget) => data != oldWidget.data;
}
