import 'dart:math' as math;

import 'package:flutter/widgets.dart';
import 'package:remix/remix.dart';

import 'computed.dart';
import 'radix_colors.dart' as radix;
import 'theme_scope.dart' show AcmeScope;
import 'tokens.dart';

/// Available accent colors matching Radix Themes names.
enum AcmeAccentColor {
  gray,
  mauve,
  slate,
  sage,
  olive,
  sand,
  gold,
  bronze,
  brown,
  yellow,
  amber,
  orange,
  tomato,
  red,
  ruby,
  crimson,
  pink,
  plum,
  purple,
  violet,
  iris,
  indigo,
  blue,
  cyan,
  teal,
  jade,
  green,
  grass,
  lime,
  mint,
  sky,
}

/// Available neutral gray families matching Radix Themes names.
enum AcmeGrayColor { gray, mauve, slate, sage, olive, sand }

/// Theme-level radius multipliers matching the Radix Themes presets.
enum AcmeRadius { none, small, medium, large, full }

/// Background treatment used by floating panels.
enum AcmePanelBackground { solid, translucent }

/// Discrete theme scaling values supported by Radix Themes.
enum AcmeScaling {
  percent90(0.9),
  percent95(0.95),
  percent100(1.0),
  percent105(1.05),
  percent110(1.1);

  const AcmeScaling(this.factor);

  /// Numeric multiplier represented by this preset.
  final double factor;
}

/// Appearance selection for a Acme scope. A root defaults to system;
/// a nested scope inherits its parent's selection when mode is omitted.
enum AcmeThemeMode { system, light, dark }

/// Partial theme values applied by a [AcmeScope].
@immutable
class AcmeThemeConfig {
  const AcmeThemeConfig({
    this.accent,
    this.gray,
    this.brightness,
    this.panelBackground,
    this.radius,
    this.scaling,
    this.hasBackground,
  });

  final AcmeAccentColor? accent;
  final AcmeGrayColor? gray;
  final Brightness? brightness;
  final AcmePanelBackground? panelBackground;
  final AcmeRadius? radius;
  final AcmeScaling? scaling;
  final bool? hasBackground;

  bool get isDark => brightness == .dark;

  AcmeThemeConfig copyWith({
    AcmeAccentColor? accent,
    AcmeGrayColor? gray,
    Brightness? brightness,
    AcmePanelBackground? panelBackground,
    AcmeRadius? radius,
    AcmeScaling? scaling,
    bool? hasBackground,
  }) => AcmeThemeConfig(
    accent: accent ?? this.accent,
    gray: gray ?? this.gray,
    brightness: brightness ?? this.brightness,
    panelBackground: panelBackground ?? this.panelBackground,
    radius: radius ?? this.radius,
    scaling: scaling ?? this.scaling,
    hasBackground: hasBackground ?? this.hasBackground,
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AcmeThemeConfig &&
          accent == other.accent &&
          gray == other.gray &&
          brightness == other.brightness &&
          panelBackground == other.panelBackground &&
          radius == other.radius &&
          scaling == other.scaling &&
          hasBackground == other.hasBackground;

  @override
  int get hashCode => Object.hash(
    accent,
    gray,
    brightness,
    panelBackground,
    radius,
    scaling,
    hasBackground,
  );

  Widget createScope({List<Type>? orderOfModifiers, required Widget child}) =>
      AcmeScope(
        accent: accent,
        gray: gray,
        brightness: brightness,
        panelBackground: panelBackground,
        radius: radius,
        scaling: scaling,
        hasBackground: hasBackground,
        orderOfModifiers: orderOfModifiers,
        child: child,
      );
}

/// Fully resolved theme values inherited by a Acme subtree.
@immutable
class AcmeThemeData extends AcmeThemeConfig {
  const AcmeThemeData({
    required AcmeAccentColor super.accent,
    required AcmeGrayColor super.gray,
    required Brightness super.brightness,
    required AcmePanelBackground super.panelBackground,
    required AcmeRadius super.radius,
    required AcmeScaling super.scaling,
    required bool super.hasBackground,
  });

  /// The preset's light appearance, with editable design options.
  const AcmeThemeData.light({
    AcmeAccentColor accent = AcmeAccentColor.indigo,
    AcmeGrayColor gray = AcmeGrayColor.slate,
    AcmePanelBackground panelBackground = AcmePanelBackground.translucent,
    AcmeRadius radius = AcmeRadius.medium,
    AcmeScaling scaling = AcmeScaling.percent100,
    bool hasBackground = true,
  }) : this(
         accent: accent,
         gray: gray,
         brightness: Brightness.light,
         panelBackground: panelBackground,
         radius: radius,
         scaling: scaling,
         hasBackground: hasBackground,
       );

  /// The preset's dark appearance, with editable design options.
  const AcmeThemeData.dark({
    AcmeAccentColor accent = AcmeAccentColor.indigo,
    AcmeGrayColor gray = AcmeGrayColor.slate,
    AcmePanelBackground panelBackground = AcmePanelBackground.translucent,
    AcmeRadius radius = AcmeRadius.medium,
    AcmeScaling scaling = AcmeScaling.percent100,
    bool hasBackground = true,
  }) : this(
         accent: accent,
         gray: gray,
         brightness: Brightness.dark,
         panelBackground: panelBackground,
         radius: radius,
         scaling: scaling,
         hasBackground: hasBackground,
       );

  @override
  AcmeAccentColor get accent => super.accent!;
  @override
  AcmeGrayColor get gray => super.gray!;
  @override
  Brightness get brightness => super.brightness!;
  @override
  AcmePanelBackground get panelBackground => super.panelBackground!;
  @override
  AcmeRadius get radius => super.radius!;
  @override
  AcmeScaling get scaling => super.scaling!;
  @override
  bool get hasBackground => super.hasBackground!;

  @override
  bool get isDark => brightness == .dark;

  @override
  AcmeThemeData copyWith({
    AcmeAccentColor? accent,
    AcmeGrayColor? gray,
    Brightness? brightness,
    AcmePanelBackground? panelBackground,
    AcmeRadius? radius,
    AcmeScaling? scaling,
    bool? hasBackground,
  }) => AcmeThemeData(
    accent: accent ?? this.accent,
    gray: gray ?? this.gray,
    brightness: brightness ?? this.brightness,
    panelBackground: panelBackground ?? this.panelBackground,
    radius: radius ?? this.radius,
    scaling: scaling ?? this.scaling,
    hasBackground: hasBackground ?? this.hasBackground,
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AcmeThemeData &&
          accent == other.accent &&
          gray == other.gray &&
          brightness == other.brightness &&
          panelBackground == other.panelBackground &&
          radius == other.radius &&
          scaling == other.scaling &&
          hasBackground == other.hasBackground;

  @override
  int get hashCode => Object.hash(
    accent,
    gray,
    brightness,
    panelBackground,
    radius,
    scaling,
    hasBackground,
  );
}

/// Builds the token map for a Acme scope. Used by [AcmeScope].
Map<MixToken<Object?>, Object> buildAcmeScopeTokens(AcmeThemeData theme) {
  final tokens = resolveAcmeTokens(theme);
  final scaling = theme.scaling.factor;
  final shadows = buildAcmeShadows(isDark: theme.isDark, colors: tokens);

  final colorTokens = {
    // Role and functional tokens
    AcmeTokens.colorBackground: tokens.colorBackground,
    AcmeTokens.colorSurface: tokens.colorSurface,
    AcmeTokens.segmentedControlIndicatorBackground: theme.isDark
        ? tokens.gray.scale.alphaStep(3)
        : tokens.colorBackground,
    AcmeTokens.colorPanelSolid: tokens.colorPanelSolid,
    AcmeTokens.colorPanelTranslucent: tokens.colorPanelTranslucent,
    AcmeTokens.colorPanel: theme.panelBackground == .solid
        ? tokens.colorPanelSolid
        : tokens.colorPanelTranslucent,
    AcmeTokens.colorOverlay: tokens.colorOverlay,
    AcmeTokens.sliderHighContrastOverlay: theme.isDark
        ? const Color(0x00000000)
        : tokens.blackAlpha[8]!,
    AcmeTokens.error3: (theme.isDark ? radix.red.dark : radix.red.light).scale
        .step(3),
    AcmeTokens.error7: (theme.isDark ? radix.red.dark : radix.red.light).scale
        .step(7),
    AcmeTokens.error8: (theme.isDark ? radix.red.dark : radix.red.light).scale
        .step(8),
    AcmeTokens.error9: (theme.isDark ? radix.red.dark : radix.red.light).scale
        .step(9),
    AcmeTokens.error11: (theme.isDark ? radix.red.dark : radix.red.light).scale
        .step(11),
    AcmeTokens.error12: (theme.isDark ? radix.red.dark : radix.red.light).scale
        .step(12),
    AcmeTokens.errorA7: (theme.isDark ? radix.red.dark : radix.red.light).scale
        .alphaStep(7),
    ..._accentColorTokens(tokens),
    // Gray steps
    AcmeTokens.gray1: tokens.gray.scale.step(1),
    AcmeTokens.gray2: tokens.gray.scale.step(2),
    AcmeTokens.gray3: tokens.gray.scale.step(3),
    AcmeTokens.gray4: tokens.gray.scale.step(4),
    AcmeTokens.gray5: tokens.gray.scale.step(5),
    AcmeTokens.gray6: tokens.gray.scale.step(6),
    AcmeTokens.gray7: tokens.gray.scale.step(7),
    AcmeTokens.gray8: tokens.gray.scale.step(8),
    AcmeTokens.gray9: tokens.gray.scale.step(9),
    AcmeTokens.gray10: tokens.gray.scale.step(10),
    AcmeTokens.gray11: tokens.gray.scale.step(11),
    AcmeTokens.gray12: tokens.gray.scale.step(12),
    // Gray role tokens (from resolved colors)
    AcmeTokens.graySurface: tokens.gray.surface,
    AcmeTokens.grayIndicator: tokens.gray.indicator,
    AcmeTokens.grayTrack: tokens.gray.track,
    AcmeTokens.grayContrast: tokens.gray.contrast,
    // Gray alpha a1..a12
    AcmeTokens.grayA1: tokens.gray.scale.alphaStep(1),
    AcmeTokens.grayA2: tokens.gray.scale.alphaStep(2),
    AcmeTokens.grayA3: tokens.gray.scale.alphaStep(3),
    AcmeTokens.grayA4: tokens.gray.scale.alphaStep(4),
    AcmeTokens.grayA5: tokens.gray.scale.alphaStep(5),
    AcmeTokens.grayA6: tokens.gray.scale.alphaStep(6),
    AcmeTokens.grayA7: tokens.gray.scale.alphaStep(7),
    AcmeTokens.grayA8: tokens.gray.scale.alphaStep(8),
    AcmeTokens.grayA9: tokens.gray.scale.alphaStep(9),
    AcmeTokens.grayA10: tokens.gray.scale.alphaStep(10),
    AcmeTokens.grayA11: tokens.gray.scale.alphaStep(11),
    AcmeTokens.grayA12: tokens.gray.scale.alphaStep(12),
    // Neutral helpers derived from primitives
    AcmeTokens.blackA1: tokens.blackAlpha[1]!,
    AcmeTokens.blackA2: tokens.blackAlpha[2]!,
    AcmeTokens.blackA3: tokens.blackAlpha[3]!,
    AcmeTokens.blackA4: tokens.blackAlpha[4]!,
    AcmeTokens.blackA5: tokens.blackAlpha[5]!,
    AcmeTokens.blackA6: tokens.blackAlpha[6]!,
    AcmeTokens.blackA7: tokens.blackAlpha[7]!,
    AcmeTokens.blackA8: tokens.blackAlpha[8]!,
    AcmeTokens.blackA9: tokens.blackAlpha[9]!,
    AcmeTokens.blackA10: tokens.blackAlpha[10]!,
    AcmeTokens.blackA11: tokens.blackAlpha[11]!,
    AcmeTokens.blackA12: tokens.blackAlpha[12]!,
    AcmeTokens.whiteA1: tokens.whiteAlpha[1]!,
    AcmeTokens.whiteA2: tokens.whiteAlpha[2]!,
    AcmeTokens.whiteA3: tokens.whiteAlpha[3]!,
    AcmeTokens.whiteA4: tokens.whiteAlpha[4]!,
    AcmeTokens.whiteA5: tokens.whiteAlpha[5]!,
    AcmeTokens.whiteA6: tokens.whiteAlpha[6]!,
    AcmeTokens.whiteA7: tokens.whiteAlpha[7]!,
    AcmeTokens.whiteA8: tokens.whiteAlpha[8]!,
    AcmeTokens.whiteA9: tokens.whiteAlpha[9]!,
    AcmeTokens.whiteA10: tokens.whiteAlpha[10]!,
    AcmeTokens.whiteA11: tokens.whiteAlpha[11]!,
    AcmeTokens.whiteA12: tokens.whiteAlpha[12]!,
    AcmeTokens.shadowStroke: tokens.shadowStroke,
    AcmeTokens.grayStroke3: mixOklabPremultiplied(
      tokens.gray.scale.alphaStep(3),
      tokens.gray.scale.step(3),
      0.25,
    ),
    AcmeTokens.grayStroke4: mixOklabPremultiplied(
      tokens.gray.scale.alphaStep(4),
      tokens.gray.scale.step(4),
      0.25,
    ),
    AcmeTokens.grayStroke5: mixOklabPremultiplied(
      tokens.gray.scale.alphaStep(5),
      tokens.gray.scale.step(5),
      0.25,
    ),
    AcmeTokens.grayStroke6: mixOklabPremultiplied(
      tokens.gray.scale.alphaStep(6),
      tokens.gray.scale.step(6),
      0.25,
    ),
    AcmeTokens.grayStroke7: mixOklabPremultiplied(
      tokens.gray.scale.alphaStep(7),
      tokens.gray.scale.step(7),
      0.25,
    ),
    AcmeTokens.dataTableBorder: mixOklabPremultiplied(
      tokens.gray.scale.alphaStep(5),
      tokens.gray.scale.step(6),
      0.5,
    ),
  };
  final allTokens = <MixToken<Object?>, Object>{
    ...colorTokens,
    AcmeTokens.panelBlur:
        theme.panelBackground == AcmePanelBackground.translucent ? 64.0 : 0.0,
    AcmeTokens.space1: 4.0 * scaling,
    AcmeTokens.space2: 8.0 * scaling,
    AcmeTokens.space3: 12.0 * scaling,
    AcmeTokens.space4: 16.0 * scaling,
    AcmeTokens.space5: 24.0 * scaling,
    AcmeTokens.space6: 32.0 * scaling,
    AcmeTokens.space7: 40.0 * scaling,
    AcmeTokens.space8: 48.0 * scaling,
    AcmeTokens.space9: 64.0 * scaling,
    AcmeTokens.spinnerSize3: 20.0 * scaling,
    AcmeTokens.dataTableRowHeight1: 36.0 * scaling,
    AcmeTokens.dataTableRowHeight2: 44.0 * scaling,
    AcmeTokens.toggleGap1: 2.0 * scaling,
    AcmeTokens.toggleGap3: 6.0 * scaling,
    AcmeTokens.avatarSize6: 80.0 * scaling,
    AcmeTokens.avatarSize7: 96.0 * scaling,
    AcmeTokens.avatarSize8: 128.0 * scaling,
    AcmeTokens.avatarSize9: 160.0 * scaling,
    AcmeTokens.avatarIconSize1: 12.0 * scaling,
    AcmeTokens.avatarIconSize2: 16.0 * scaling,
    AcmeTokens.avatarIconSize3: 20.0 * scaling,
    AcmeTokens.avatarIconSize4: 24.0 * scaling,
    AcmeTokens.avatarIconSize5: 32.0 * scaling,
    AcmeTokens.avatarIconSize6: 40.0 * scaling,
    AcmeTokens.avatarIconSize7: 48.0 * scaling,
    AcmeTokens.avatarIconSize8: 64.0 * scaling,
    AcmeTokens.avatarIconSize9: 80.0 * scaling,
    AcmeTokens.badgePaddingX1: 6.0 * scaling,
    AcmeTokens.badgePaddingY1: 2.0 * scaling,
    AcmeTokens.badgePaddingX3: 10.0 * scaling,
    AcmeTokens.checkboxSize1: 14.0 * scaling,
    AcmeTokens.checkboxSize3: 20.0 * scaling,
    AcmeTokens.checkboxIndicatorSize1: 9.0 * scaling,
    AcmeTokens.checkboxIndicatorSize2: 10.0 * scaling,
    AcmeTokens.checkboxIndicatorSize3: 12.0 * scaling,
    AcmeTokens.checkboxGroupItemGap1: 6.0 * scaling,
    AcmeTokens.checkboxGroupItemGap2: 7.0 * scaling,
    AcmeTokens.checkboxGroupItemGap3: 8.0 * scaling,
    AcmeTokens.radioIndicatorSize1: 5.6 * scaling,
    AcmeTokens.radioIndicatorSize2: 6.4 * scaling,
    AcmeTokens.radioIndicatorSize3: 8.0 * scaling,
    AcmeTokens.checkboxRadius1: _scaledRadiusToken(
      theme.radius,
      scaling,
      3.0 * 0.875,
    ),
    AcmeTokens.checkboxRadius3: _scaledRadiusToken(
      theme.radius,
      scaling,
      3.0 * 1.25,
    ),
    AcmeTokens.switchHeight2: 20.0 * scaling,
    AcmeTokens.switchWidth1: 28.0 * scaling,
    AcmeTokens.switchWidth2: 35.0 * scaling,
    AcmeTokens.switchWidth3: 42.0 * scaling,
    AcmeTokens.switchThumbSize1: 16.0 * scaling - 2.0,
    AcmeTokens.switchThumbSize2: 20.0 * scaling - 2.0,
    AcmeTokens.switchThumbSize3: 24.0 * scaling - 2.0,
    AcmeTokens.progressHeight2: 6.0 * scaling,
    AcmeTokens.sliderTrackSize1: 6.0 * scaling,
    AcmeTokens.sliderTrackSize2: 8.0 * scaling,
    AcmeTokens.sliderTrackSize3: 10.0 * scaling,
    AcmeTokens.sliderThumbSize1: 13.0 * scaling,
    AcmeTokens.sliderThumbSize2: 16.0 * scaling,
    AcmeTokens.sliderThumbSize3: 19.0 * scaling,
    AcmeTokens.textFieldPadding1: 6.0 * scaling,
    AcmeTokens.textFieldPadding2: 8.0 * scaling,
    AcmeTokens.textFieldPadding3: 12.0 * scaling,
    AcmeTokens.textAreaMinHeight3: 80.0,
    AcmeTokens.dataListRowGap3: 20.0 * scaling,
    AcmeTokens.dataListLabelMinWidth: 120.0,
    AcmeTokens.tabInnerPaddingY1: 2.0 * scaling,
    AcmeTokens.tabActiveLetterSpacing1: -0.12 * scaling,
    AcmeTokens.tabActiveLetterSpacing2: -0.14 * scaling,
    AcmeTokens.selectSpace1Half: 6.0 * scaling,
    AcmeTokens.selectIndicatorWidth1: 20.0 * scaling,
    AcmeTokens.selectIndicatorSize1: 8.0 * scaling,
    AcmeTokens.selectIndicatorSize2: 10.0 * scaling,
    AcmeTokens.selectGhostMarginX12: -8.0 * scaling,
    AcmeTokens.selectGhostMarginY12: -4.0 * scaling,
    AcmeTokens.selectGhostMarginX3: -12.0 * scaling,
    AcmeTokens.selectGhostMarginY3: -6.0 * scaling,
    ..._radiusTokensFor(theme.radius, scaling),

    // Exact layered Radix shadow tokens, resolved for the active color scales.
    ...shadows,
    AcmeTokens.sliderClassicDisabledTrackShadows: _scaleShadowOpacity(
      shadows[AcmeTokens.shadow1Layers]! as List<RemixBoxShadow>,
      0.5,
    ),
    AcmeTokens.cardClassicOuterShadows: _cardClassicShadows(
      tokens,
      isDark: theme.isDark,
      layer: .outer,
      state: .idle,
    ),
    AcmeTokens.cardClassicInnerShadows: _cardClassicShadows(
      tokens,
      isDark: theme.isDark,
      layer: .inner,
      state: .idle,
    ),
    AcmeTokens.cardClassicHoverOuterShadows: _cardClassicShadows(
      tokens,
      isDark: theme.isDark,
      layer: .outer,
      state: .hovered,
    ),
    AcmeTokens.cardClassicHoverInnerShadows: _cardClassicShadows(
      tokens,
      isDark: theme.isDark,
      layer: .inner,
      state: .hovered,
    ),
    AcmeTokens.cardClassicActiveOuterShadows: _cardClassicShadows(
      tokens,
      isDark: theme.isDark,
      layer: .outer,
      state: .active,
    ),
    AcmeTokens.cardClassicActiveInnerShadows: _cardClassicShadows(
      tokens,
      isDark: theme.isDark,
      layer: .inner,
      state: .active,
    ),
    AcmeTokens.selectTriggerClassicShadows: _selectClassicShadows(
      tokens,
      isDark: theme.isDark,
    ),
    AcmeTokens.selectTriggerClassicHoverShadows: [
      _insetShadow(tokens.gray.scale.alphaStep(3), spread: 1),
      ..._selectClassicShadows(tokens, isDark: theme.isDark),
    ],
    AcmeTokens.baseButtonClassicDisabledShadows:
        _baseButtonClassicDisabledShadows(tokens, isDark: theme.isDark),
    AcmeTokens.baseButtonClassicShadows: _baseButtonClassicShadows(
      tokens,
      isDark: theme.isDark,
      highContrast: false,
    ),
    AcmeTokens.baseButtonClassicHighContrastShadows: _baseButtonClassicShadows(
      tokens,
      isDark: theme.isDark,
      highContrast: true,
    ),
    AcmeTokens.baseButtonClassicActiveShadows: _baseButtonClassicActiveShadows(
      tokens,
      highContrast: false,
    ),
    AcmeTokens.baseButtonClassicActiveHighContrastShadows:
        _baseButtonClassicActiveShadows(tokens, highContrast: true),
    AcmeTokens.baseButtonClassicAfterInset: theme.isDark ? 1.0 : 2.0,
    AcmeTokens.baseButtonGhostPaddingY3: 6.0 * scaling,
    AcmeTokens.baseButtonGhostMarginX12: -8.0 * scaling,
    AcmeTokens.baseButtonGhostMarginY12: -4.0 * scaling,
    AcmeTokens.baseButtonGhostMarginX3: -12.0 * scaling,
    AcmeTokens.baseButtonGhostMarginY3: -6.0 * scaling,
    AcmeTokens.baseButtonGhostMarginX4: -16.0 * scaling,
    AcmeTokens.baseButtonGhostMarginY4: -8.0 * scaling,
    AcmeTokens.iconButtonGhostPadding2: 6.0 * scaling,
    AcmeTokens.iconButtonGhostMargin1: -4.0 * scaling,
    AcmeTokens.iconButtonGhostMargin2: -6.0 * scaling,
    AcmeTokens.iconButtonGhostMargin3: -8.0 * scaling,
    AcmeTokens.iconButtonGhostMargin4: -12.0 * scaling,
    AcmeTokens.cardGhostMargin1: -12.0 * scaling,
    AcmeTokens.cardGhostMargin2: -16.0 * scaling,
    AcmeTokens.cardGhostMargin3: -24.0 * scaling,
    AcmeTokens.cardGhostMargin4: -32.0 * scaling,
    AcmeTokens.cardGhostMargin5: -48.0 * scaling,
    AcmeTokens.borderWidth1: 1.0,
    AcmeTokens.borderWidth2: 2.0,
    AcmeTokens.focusRingWidth: 2.0,
    AcmeTokens.focusRingOffset: 2.0,
    AcmeTokens.text1: TextStyle(
      fontSize: 12.0 * scaling,
      letterSpacing: 0.0025 * 12.0 * scaling,
      height: 16.0 / 12.0,
    ),
    AcmeTokens.text2: TextStyle(
      fontSize: 14.0 * scaling,
      letterSpacing: 0.0,
      height: 20.0 / 14.0,
    ),
    AcmeTokens.text3: TextStyle(
      fontSize: 16.0 * scaling,
      letterSpacing: 0.0,
      height: 24.0 / 16.0,
    ),
    AcmeTokens.accordionText2: TextStyle(
      fontSize: 15.0 * scaling,
      letterSpacing: 0.0,
      height: 20.0 / 15.0,
    ),
    AcmeTokens.text4: TextStyle(
      fontSize: 18.0 * scaling,
      letterSpacing: -0.0025 * 18.0 * scaling,
      height: 26.0 / 18.0,
    ),
    AcmeTokens.text5: TextStyle(
      fontSize: 20.0 * scaling,
      letterSpacing: -0.005 * 20.0 * scaling,
      height: 28.0 / 20.0,
    ),
    AcmeTokens.text6: TextStyle(
      fontSize: 24.0 * scaling,
      letterSpacing: -0.00625 * 24.0 * scaling,
      height: 30.0 / 24.0,
    ),
    AcmeTokens.text7: TextStyle(
      fontSize: 28.0 * scaling,
      letterSpacing: -0.0075 * 28.0 * scaling,
      height: 36.0 / 28.0,
    ),
    AcmeTokens.text8: TextStyle(
      fontSize: 35.0 * scaling,
      letterSpacing: -0.01 * 35.0 * scaling,
      height: 40.0 / 35.0,
    ),
    AcmeTokens.text9: TextStyle(
      fontSize: 60.0 * scaling,
      letterSpacing: -0.025 * 60.0 * scaling,
      height: 1.0,
    ),
    AcmeTokens.avatarFallback1One: _avatarFallbackText(
      fontSize: 14,
      letterSpacing: 0.0025 * 12,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback1Two: _avatarFallbackText(
      fontSize: 12,
      letterSpacing: 0.0025 * 12,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback2One: _avatarFallbackText(
      fontSize: 16,
      letterSpacing: 0,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback2Two: _avatarFallbackText(
      fontSize: 14,
      letterSpacing: 0,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback3One: _avatarFallbackText(
      fontSize: 18,
      letterSpacing: 0,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback3Two: _avatarFallbackText(
      fontSize: 16,
      letterSpacing: 0,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback4One: _avatarFallbackText(
      fontSize: 20,
      letterSpacing: -0.0025 * 18,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback4Two: _avatarFallbackText(
      fontSize: 18,
      letterSpacing: -0.0025 * 18,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback5: _avatarFallbackText(
      fontSize: 24,
      letterSpacing: -0.00625 * 24,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback6: _avatarFallbackText(
      fontSize: 28,
      letterSpacing: -0.0075 * 28,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback7: _avatarFallbackText(
      fontSize: 28,
      letterSpacing: -0.0075 * 28,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback8: _avatarFallbackText(
      fontSize: 35,
      letterSpacing: -0.01 * 35,
      scaling: scaling,
    ),
    AcmeTokens.avatarFallback9: _avatarFallbackText(
      fontSize: 60,
      letterSpacing: -0.025 * 60,
      scaling: scaling,
    ),

    // Font weights (token values)
    AcmeTokens.fontWeightLight: FontWeight.w300,
    AcmeTokens.fontWeightRegular: FontWeight.w400,
    AcmeTokens.fontWeightMedium: FontWeight.w500,
    // Match Radix Themes font weights (bold = 700)
    AcmeTokens.fontWeightBold: FontWeight.w700,

    // Durations (token values)
    AcmeTokens.transitionFast: const Duration(milliseconds: 100),
    AcmeTokens.transitionSlow: const Duration(milliseconds: 300),
    AcmeTokens.skeletonPulseDuration: const Duration(milliseconds: 1000),
  };

  return allTokens;
}

TextStyle _avatarFallbackText({
  required double fontSize,
  required double letterSpacing,
  required double scaling,
}) => TextStyle(
  fontSize: fontSize * scaling,
  letterSpacing: letterSpacing * scaling,
  height: 1,
);

enum _CardShadowLayer { outer, inner }

enum _CardShadowState { idle, hovered, active }

List<RemixBoxShadow> _cardClassicShadows(
  AcmeThemeColors colors, {
  required bool isDark,
  required _CardShadowLayer layer,
  required _CardShadowState state,
}) {
  final inner = layer == _CardShadowLayer.inner;
  final shapeInset = inner ? 1.0 : 0.0;
  final border = switch ((isDark, state)) {
    (true, _) => mixOklabPremultiplied(
      colors.gray.scale.alphaStep(6),
      colors.gray.scale.step(6),
      0.25,
    ),
    (false, _CardShadowState.hovered) => mixOklabPremultiplied(
      colors.gray.scale.alphaStep(4),
      colors.gray.scale.step(4),
      0.25,
    ),
    (false, _) => mixOklabPremultiplied(
      colors.gray.scale.alphaStep(3),
      colors.gray.scale.step(3),
      0.25,
    ),
  };

  RemixBoxShadow shadow(
    Color color, {
    Offset offset = Offset.zero,
    double blur = 0,
    required double spread,
  }) => RemixBoxShadow(
    color: color,
    offset: offset,
    blurRadius: blur,
    spreadRadius: spread,
    shapeInset: shapeInset,
  );

  if (state == _CardShadowState.hovered) {
    if (isDark) {
      return [
        shadow(border, spread: inner ? 1 : 0),
        shadow(colors.gray.scale.alphaStep(4), blur: 1, spread: inner ? 1 : 0),
        shadow(
          colors.gray.scale.alphaStep(4),
          blur: 1,
          spread: inner ? -1 : -2,
        ),
        shadow(
          colors.gray.scale.alphaStep(3),
          blur: 3,
          spread: inner ? -2 : -3,
        ),
        shadow(
          colors.gray.scale.alphaStep(3),
          blur: 12,
          spread: inner ? -2 : -3,
        ),
        shadow(
          colors.gray.scale.alphaStep(7),
          blur: 16,
          spread: inner ? -8 : -9,
        ),
      ];
    }
    return [
      shadow(border, spread: inner ? 1 : 0),
      shadow(
        colors.blackAlpha[1]!,
        offset: const Offset(0, 1),
        blur: 1,
        spread: inner ? 1 : 0,
      ),
      shadow(
        colors.gray.scale.alphaStep(3),
        offset: const Offset(0, 2),
        blur: 1,
        spread: inner ? -1 : -2,
      ),
      shadow(
        colors.blackAlpha[1]!,
        offset: const Offset(0, 2),
        blur: 3,
        spread: inner ? -2 : -3,
      ),
      shadow(
        colors.gray.scale.alphaStep(3),
        offset: const Offset(0, 3),
        blur: 12,
        spread: inner ? -4 : -5,
      ),
      shadow(
        colors.blackAlpha[1]!,
        offset: const Offset(0, 4),
        blur: 16,
        spread: inner ? -8 : -9,
      ),
    ];
  }

  final active = state == _CardShadowState.active;
  final subtle = isDark ? colors.blackAlpha[3]! : colors.blackAlpha[1]!;
  final middle = isDark
      ? colors.blackAlpha[6]!
      : colors.gray.scale.alphaStep(active ? 4 : 2);
  final bottom = isDark ? colors.blackAlpha[5]! : colors.blackAlpha[1]!;
  return [
    shadow(border, spread: inner ? 1 : 0),
    shadow(const Color(0x00000000), spread: inner ? 1 : 0),
    shadow(subtle, spread: inner ? 0.5 : 0),
    shadow(middle, offset: const Offset(0, 1), blur: 1, spread: inner ? 0 : -1),
    shadow(
      isDark ? colors.blackAlpha[6]! : colors.blackAlpha[1]!,
      offset: const Offset(0, 2),
      blur: 1,
      spread: inner ? -1 : -2,
    ),
    shadow(bottom, offset: const Offset(0, 1), blur: 3, spread: inner ? 0 : -1),
  ];
}

RemixBoxShadow _insetShadow(
  Color color, {
  Offset offset = Offset.zero,
  double blur = 0,
  double spread = 0,
  double shapeInset = 0,
}) => RemixBoxShadow(
  kind: RemixBoxShadowKind.inset,
  color: color,
  offset: offset,
  blurRadius: blur,
  spreadRadius: spread,
  shapeInset: shapeInset,
);

List<RemixBoxShadow> _selectClassicShadows(
  AcmeThemeColors colors, {
  required bool isDark,
}) {
  if (isDark) {
    return [
      _insetShadow(colors.whiteAlpha[4]!, spread: 1),
      _insetShadow(colors.whiteAlpha[4]!, offset: const Offset(0, 1), blur: 1),
      _insetShadow(colors.blackAlpha[9]!, offset: const Offset(0, -1), blur: 1),
    ];
  }
  return [
    _insetShadow(colors.gray.scale.alphaStep(5), spread: 1),
    _insetShadow(colors.whiteAlpha[11]!, offset: const Offset(0, 2), blur: 1),
    _insetShadow(
      colors.gray.scale.alphaStep(4),
      offset: const Offset(0, -2),
      blur: 1,
    ),
  ];
}

List<RemixBoxShadow> _baseButtonClassicDisabledShadows(
  AcmeThemeColors colors, {
  required bool isDark,
}) {
  if (isDark) {
    return [
      _insetShadow(colors.gray.scale.alphaStep(5), spread: 1),
      _insetShadow(
        colors.gray.scale.alphaStep(2),
        offset: const Offset(0, 4),
        blur: 2,
        spread: -2,
      ),
      _insetShadow(
        colors.gray.scale.alphaStep(5),
        offset: const Offset(0, 1),
        blur: 1,
      ),
      _insetShadow(colors.blackAlpha[3]!, offset: const Offset(0, -1), blur: 1),
      _insetShadow(colors.gray.scale.alphaStep(2), spread: 1),
    ];
  }
  return [
    _insetShadow(colors.gray.scale.alphaStep(4), spread: 1),
    _insetShadow(
      colors.gray.scale.alphaStep(3),
      offset: const Offset(0, -2),
      blur: 1,
    ),
    _insetShadow(
      colors.whiteAlpha[9]!,
      offset: const Offset(0, 4),
      blur: 2,
      spread: -2,
    ),
    _insetShadow(
      colors.whiteAlpha[9]!,
      offset: const Offset(0, 2),
      blur: 1,
      spread: -1,
    ),
  ];
}

List<RemixBoxShadow> _baseButtonClassicShadows(
  AcmeThemeColors colors, {
  required bool isDark,
  required bool highContrast,
}) {
  final accent = highContrast
      ? colors.accent.scale.step(12)
      : colors.accent.scale.step(9);
  if (isDark) {
    return [
      _insetShadow(
        colors.whiteAlpha[4]!,
        offset: const Offset(0, 2),
        blur: 3,
        spread: -1,
        shapeInset: 1,
      ),
      _insetShadow(colors.whiteAlpha[2]!, spread: 1),
      _insetShadow(
        colors.whiteAlpha[3]!,
        offset: const Offset(0, 4),
        blur: 2,
        spread: -2,
      ),
      _insetShadow(colors.whiteAlpha[6]!, offset: const Offset(0, 1), blur: 1),
      _insetShadow(colors.blackAlpha[6]!, offset: const Offset(0, -1), blur: 1),
      _insetShadow(accent, spread: 1),
    ];
  }
  return [
    _insetShadow(
      colors.whiteAlpha[4]!,
      offset: const Offset(0, 2),
      blur: 3,
      spread: -1,
      shapeInset: 2,
    ),
    _insetShadow(colors.gray.scale.alphaStep(4), spread: 1),
    _insetShadow(
      colors.gray.scale.alphaStep(3),
      offset: const Offset(0, -2),
      blur: 1,
    ),
    _insetShadow(accent, spread: 1),
    _insetShadow(
      colors.whiteAlpha[9]!,
      offset: const Offset(0, 4),
      blur: 2,
      spread: -2,
    ),
    _insetShadow(
      colors.whiteAlpha[9]!,
      offset: const Offset(0, 2),
      blur: 1,
      spread: -1,
    ),
  ];
}

List<RemixBoxShadow> _baseButtonClassicActiveShadows(
  AcmeThemeColors colors, {
  required bool highContrast,
}) {
  final accent = highContrast
      ? colors.accent.scale.step(12)
      : colors.accent.scale.step(9);
  return [
    _insetShadow(
      colors.gray.scale.alphaStep(4),
      offset: const Offset(0, 4),
      blur: 2,
      spread: -2,
    ),
    _insetShadow(
      colors.gray.scale.alphaStep(7),
      offset: const Offset(0, 1),
      blur: 1,
    ),
    _insetShadow(colors.gray.scale.alphaStep(5), spread: 1),
    _insetShadow(accent, spread: 1),
    _insetShadow(
      colors.gray.scale.alphaStep(3),
      offset: const Offset(0, 3),
      blur: 2,
    ),
    _insetShadow(colors.whiteAlpha[7]!, spread: 1),
    _insetShadow(colors.whiteAlpha[5]!, offset: const Offset(0, -2), blur: 1),
  ];
}

Map<RadiusToken, Radius> _radiusTokensFor(AcmeRadius radius, double scaling) {
  final factor = _radiusFactor(radius);
  final thumb = switch (radius) {
    .none || .small => const Radius.circular(0.5),
    .medium || .large || .full => const Radius.circular(9999.0),
  };
  Radius scaled(double base) => Radius.circular(base * factor * scaling);
  Radius larger(Radius first, Radius second) => Radius.elliptical(
    first.x > second.x ? first.x : second.x,
    first.y > second.y ? first.y : second.y,
  );
  final radius1 = scaled(3.0);
  final radius2 = scaled(4.0);
  final radius3 = scaled(6.0);
  final radius4 = scaled(8.0);
  final radius5 = scaled(12.0);
  final radius6 = scaled(16.0);
  final full = radius == .full ? const Radius.circular(9999.0) : Radius.zero;
  Radius progressRadius(double height) {
    final thumbBase = switch (radius) {
      .none || .small => 0.5,
      .medium || .large || .full => 9999.0,
    };
    return Radius.circular(math.max(factor * height / 3, factor * thumbBase));
  }

  return {
    AcmeTokens.radius1: radius1,
    AcmeTokens.radius2: radius2,
    AcmeTokens.radius3: radius3,
    AcmeTokens.radius4: radius4,
    AcmeTokens.radius5: radius5,
    AcmeTokens.radius6: radius6,
    AcmeTokens.radiusFull: full,
    AcmeTokens.radiusThumb: thumb,
    AcmeTokens.radiusCircle: const Radius.circular(9999.0),
    AcmeTokens.radius1OrFull: larger(radius1, full),
    AcmeTokens.radius2OrFull: larger(radius2, full),
    AcmeTokens.radius3OrFull: larger(radius3, full),
    AcmeTokens.radius4OrFull: larger(radius4, full),
    AcmeTokens.radius5OrFull: larger(radius5, full),
    AcmeTokens.radius6OrFull: larger(radius6, full),
    AcmeTokens.radius1OrThumb: larger(radius1, thumb),
    AcmeTokens.radius2OrThumb: larger(radius2, thumb),
    AcmeTokens.progressRadius1: progressRadius(4.0 * scaling),
    AcmeTokens.progressRadius2: progressRadius(6.0 * scaling),
    AcmeTokens.progressRadius3: progressRadius(8.0 * scaling),
    AcmeTokens.sliderTrackRadius1: progressRadius(6.0 * scaling),
    AcmeTokens.sliderTrackRadius2: progressRadius(8.0 * scaling),
    AcmeTokens.sliderTrackRadius3: progressRadius(10.0 * scaling),
  };
}

List<RemixBoxShadow> _scaleShadowOpacity(
  List<RemixBoxShadow> shadows,
  double factor,
) => [
  for (final shadow in shadows)
    RemixBoxShadow(
      kind: shadow.kind,
      color: shadow.color.withValues(alpha: shadow.color.a * factor),
      offset: shadow.offset,
      blurRadius: shadow.blurRadius,
      spreadRadius: shadow.spreadRadius,
      shapeInset: shadow.shapeInset,
    ),
];

double _radiusFactor(AcmeRadius radius) => switch (radius) {
  .none => 0.0,
  .small => 0.75,
  .medium => 1.0,
  .large || .full => 1.5,
};

Radius _scaledRadiusToken(AcmeRadius radius, double scaling, double base) =>
    Radius.circular(base * scaling * _radiusFactor(radius));

Map<ColorToken, Color> _accentColorTokens(AcmeThemeColors tokens) {
  final scale = tokens.accent.scale;

  return {
    AcmeTokens.accentSurface: tokens.accent.surface,
    AcmeTokens.accentIndicator: tokens.accent.indicator,
    AcmeTokens.accentTrack: tokens.accent.track,
    AcmeTokens.accentContrast: tokens.accent.contrast,
    AcmeTokens.focus8: tokens.focus8,
    AcmeTokens.focusA5: tokens.focusA5,
    AcmeTokens.focusA8: tokens.focusA8,
    AcmeTokens.accent1: scale.step(1),
    AcmeTokens.accent2: scale.step(2),
    AcmeTokens.accent3: scale.step(3),
    AcmeTokens.accent4: scale.step(4),
    AcmeTokens.accent5: scale.step(5),
    AcmeTokens.accent6: scale.step(6),
    AcmeTokens.accent7: scale.step(7),
    AcmeTokens.accent8: scale.step(8),
    AcmeTokens.accent9: scale.step(9),
    AcmeTokens.accent10: scale.step(10),
    AcmeTokens.accent11: scale.step(11),
    AcmeTokens.accent12: scale.step(12),
    AcmeTokens.accentA1: scale.alphaStep(1),
    AcmeTokens.accentA2: scale.alphaStep(2),
    AcmeTokens.accentA3: scale.alphaStep(3),
    AcmeTokens.accentA4: scale.alphaStep(4),
    AcmeTokens.accentA5: scale.alphaStep(5),
    AcmeTokens.accentA6: scale.alphaStep(6),
    AcmeTokens.accentA7: scale.alphaStep(7),
    AcmeTokens.accentA8: scale.alphaStep(8),
    AcmeTokens.accentA9: scale.alphaStep(9),
    AcmeTokens.accentA10: scale.alphaStep(10),
    AcmeTokens.accentA11: scale.alphaStep(11),
    AcmeTokens.accentA12: scale.alphaStep(12),
  };
}
