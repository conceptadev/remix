// GENERATED CODE - DO NOT EDIT
// Generated from: sRGB fallback tokens extracted from the pinned @radix-ui/themes npm artifact
// Radix Themes version: 3.3.0
// Radix Colors version: bundled with Radix Themes 3.3.0
// Source integrity: sha512-I0/h2CRNTpYNB7Mi3xFIvSsQq5a108d7kK8dTO5zp5b9HR5QJXKag6B8tjpz2ITkVYkFdkGk45doNkSr7OxwNw==

library;

import 'package:flutter/painting.dart';

class RadixColor {
  final RadixColorScale scale;
  final Color surface;
  final Color indicator;
  final Color track;
  final Color contrast;

  const RadixColor(
    this.scale,
    this.surface,
    this.indicator,
    this.track,
    this.contrast,
  );
}

class RadixColorTheme {
  final RadixColor light;
  final RadixColor dark;

  const RadixColorTheme(this.light, this.dark);
}

class RadixColorScale {
  final ColorSwatch<int> solid;
  final ColorSwatch<int> alpha;

  const RadixColorScale(this.solid, this.alpha);

  /// The most subtle background color (step 1).
  Color get appBackground => step(1);

  /// Subtle background with slightly more presence (step 2).
  Color get subtleBackground => step(2);

  /// Default background for interactive components (step 3).
  Color get componentBackground => step(3);

  /// Background color for components on hover (step 4).
  Color get componentBackgroundHover => step(4);

  /// Background color for active/pressed components (step 5).
  Color get componentBackgroundActive => step(5);

  /// Subtle border color for gentle separation (step 6).
  Color get subtleBorder => step(6);

  /// Standard border color for components (step 7).
  Color get componentBorder => step(7);

  /// Border color for hover and focus states (step 8).
  Color get componentBorderHover => step(8);

  /// Primary solid background color (step 9).
  Color get solidBackground => step(9);

  /// Solid background color on hover (step 10).
  Color get solidBackgroundHover => step(10);

  /// Low contrast text color (step 11).
  Color get lowContrastText => step(11);

  /// High contrast text color (step 12).
  Color get highContrastText => step(12);

  /// Gets a solid color from the 12-step scale.
  ///
  /// Steps must be between 1 and 12. Falls back to step 9 if unavailable.
  Color step(int n) {
    assert(n >= 1 && n <= 12, 'Step must be between 1 and 12');

    return solid[n] ?? solid[9]!;
  }

  /// Gets a translucent color from the 12-step alpha scale.
  ///
  /// Alpha variants maintain saturation when composited.
  /// Falls back to alpha step 9 if unavailable.
  Color alphaStep(int n) {
    assert(n >= 1 && n <= 12, 'Step must be between 1 and 12');

    return alpha[n] ?? alpha[9]!;
  }
}

// gray color scale
const _grayLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff8d8d8d, {
      1: Color(0xfffcfcfc),
      2: Color(0xfff9f9f9),
      3: Color(0xfff0f0f0),
      4: Color(0xffe8e8e8),
      5: Color(0xffe0e0e0),
      6: Color(0xffd9d9d9),
      7: Color(0xffcecece),
      8: Color(0xffbbbbbb),
      9: Color(0xff8d8d8d),
      10: Color(0xff838383),
      11: Color(0xff646464),
      12: Color(0xff202020),
    }),
    ColorSwatch(0x72000000, {
      1: Color(0x03000000),
      2: Color(0x06000000),
      3: Color(0x0f000000),
      4: Color(0x17000000),
      5: Color(0x1f000000),
      6: Color(0x26000000),
      7: Color(0x31000000),
      8: Color(0x44000000),
      9: Color(0x72000000),
      10: Color(0x7c000000),
      11: Color(0x9b000000),
      12: Color(0xdf000000),
    }),
  ),
  Color(0xccffffff),
  Color(0xff8d8d8d),
  Color(0xff8d8d8d),
  Color(0xffffffff),
);

const _grayDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff6e6e6e, {
      1: Color(0xff111111),
      2: Color(0xff191919),
      3: Color(0xff222222),
      4: Color(0xff2a2a2a),
      5: Color(0xff313131),
      6: Color(0xff3a3a3a),
      7: Color(0xff484848),
      8: Color(0xff606060),
      9: Color(0xff6e6e6e),
      10: Color(0xff7b7b7b),
      11: Color(0xffb4b4b4),
      12: Color(0xffeeeeee),
    }),
    ColorSwatch(0x64ffffff, {
      1: Color(0x00000000),
      2: Color(0x09ffffff),
      3: Color(0x12ffffff),
      4: Color(0x1bffffff),
      5: Color(0x22ffffff),
      6: Color(0x2cffffff),
      7: Color(0x3bffffff),
      8: Color(0x55ffffff),
      9: Color(0x64ffffff),
      10: Color(0x72ffffff),
      11: Color(0xafffffff),
      12: Color(0xedffffff),
    }),
  ),
  Color(0x80212121),
  Color(0xff6e6e6e),
  Color(0xff6e6e6e),
  Color(0xffffffff),
);

// mauve color scale
const _mauveLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff8e8c99, {
      1: Color(0xfffdfcfd),
      2: Color(0xfffaf9fb),
      3: Color(0xfff2eff3),
      4: Color(0xffeae7ec),
      5: Color(0xffe3dfe6),
      6: Color(0xffdbd8e0),
      7: Color(0xffd0cdd7),
      8: Color(0xffbcbac7),
      9: Color(0xff8e8c99),
      10: Color(0xff84828e),
      11: Color(0xff65636d),
      12: Color(0xff211f26),
    }),
    ColorSwatch(0x7305001d, {
      1: Color(0x03550055),
      2: Color(0x062b0055),
      3: Color(0x10300040),
      4: Color(0x18200036),
      5: Color(0x20200038),
      6: Color(0x27140035),
      7: Color(0x32100033),
      8: Color(0x45080031),
      9: Color(0x7305001d),
      10: Color(0x7d050019),
      11: Color(0x9c040011),
      12: Color(0xe0020008),
    }),
  ),
  Color(0xccffffff),
  Color(0xff8e8c99),
  Color(0xff8e8c99),
  Color(0xffffffff),
);

const _mauveDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff6f6d78, {
      1: Color(0xff121113),
      2: Color(0xff1a191b),
      3: Color(0xff232225),
      4: Color(0xff2b292d),
      5: Color(0xff323035),
      6: Color(0xff3c393f),
      7: Color(0xff49474e),
      8: Color(0xff625f69),
      9: Color(0xff6f6d78),
      10: Color(0xff7c7a85),
      11: Color(0xffb5b2bc),
      12: Color(0xffeeeef0),
    }),
    ColorSwatch(0x6eeae6fd, {
      1: Color(0x00000000),
      2: Color(0x09f5f4f6),
      3: Color(0x14ebeaf8),
      4: Color(0x1deee5f8),
      5: Color(0x25efe6fe),
      6: Color(0x30f1e6fd),
      7: Color(0x40eee9ff),
      8: Color(0x5deee7ff),
      9: Color(0x6eeae6fd),
      10: Color(0x7cece9fd),
      11: Color(0xb7f5f1ff),
      12: Color(0xeffdfdff),
    }),
  ),
  Color(0x80222123),
  Color(0xff6f6d78),
  Color(0xff6f6d78),
  Color(0xffffffff),
);

// slate color scale
const _slateLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff8b8d98, {
      1: Color(0xfffcfcfd),
      2: Color(0xfff9f9fb),
      3: Color(0xfff0f0f3),
      4: Color(0xffe8e8ec),
      5: Color(0xffe0e1e6),
      6: Color(0xffd9d9e0),
      7: Color(0xffcdced6),
      8: Color(0xffb9bbc6),
      9: Color(0xff8b8d98),
      10: Color(0xff80838d),
      11: Color(0xff60646c),
      12: Color(0xff1c2024),
    }),
    ColorSwatch(0x7400051d, {
      1: Color(0x03000055),
      2: Color(0x06000055),
      3: Color(0x0f000033),
      4: Color(0x1700002d),
      5: Color(0x1f000932),
      6: Color(0x2600002f),
      7: Color(0x3200062e),
      8: Color(0x46000830),
      9: Color(0x7400051d),
      10: Color(0x7f00071b),
      11: Color(0x9f000714),
      12: Color(0xe3000509),
    }),
  ),
  Color(0xccffffff),
  Color(0xff8b8d98),
  Color(0xff8b8d98),
  Color(0xffffffff),
);

const _slateDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff696e77, {
      1: Color(0xff111113),
      2: Color(0xff18191b),
      3: Color(0xff212225),
      4: Color(0xff272a2d),
      5: Color(0xff2e3135),
      6: Color(0xff363a3f),
      7: Color(0xff43484e),
      8: Color(0xff5a6169),
      9: Color(0xff696e77),
      10: Color(0xff777b84),
      11: Color(0xffb0b4ba),
      12: Color(0xffedeef0),
    }),
    ColorSwatch(0x6ddfebfd, {
      1: Color(0x00000000),
      2: Color(0x09d8f4f6),
      3: Color(0x14ddeaf8),
      4: Color(0x1dd3edf8),
      5: Color(0x25d9edfe),
      6: Color(0x30d6ebfd),
      7: Color(0x40d9edff),
      8: Color(0x5dd9edff),
      9: Color(0x6ddfebfd),
      10: Color(0x7be5edfd),
      11: Color(0xb5f1f7fe),
      12: Color(0xeffcfdff),
    }),
  ),
  Color(0x801f2123),
  Color(0xff696e77),
  Color(0xff696e77),
  Color(0xffffffff),
);

// sage color scale
const _sageLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff868e8b, {
      1: Color(0xfffbfdfc),
      2: Color(0xfff7f9f8),
      3: Color(0xffeef1f0),
      4: Color(0xffe6e9e8),
      5: Color(0xffdfe2e0),
      6: Color(0xffd7dad9),
      7: Color(0xffcbcfcd),
      8: Color(0xffb8bcba),
      9: Color(0xff868e8b),
      10: Color(0xff7c8481),
      11: Color(0xff5f6563),
      12: Color(0xff1a211e),
    }),
    ColorSwatch(0x7900110b, {
      1: Color(0x04008040),
      2: Color(0x08004020),
      3: Color(0x11002d1e),
      4: Color(0x19001f15),
      5: Color(0x20001808),
      6: Color(0x2800140d),
      7: Color(0x3400140a),
      8: Color(0x47000f08),
      9: Color(0x7900110b),
      10: Color(0x8300100a),
      11: Color(0xa0000a07),
      12: Color(0xe5000805),
    }),
  ),
  Color(0xccffffff),
  Color(0xff868e8b),
  Color(0xff868e8b),
  Color(0xffffffff),
);

const _sageDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff63706b, {
      1: Color(0xff101211),
      2: Color(0xff171918),
      3: Color(0xff202221),
      4: Color(0xff272a29),
      5: Color(0xff2e3130),
      6: Color(0xff373b39),
      7: Color(0xff444947),
      8: Color(0xff5b625f),
      9: Color(0xff63706b),
      10: Color(0xff717d79),
      11: Color(0xffadb5b2),
      12: Color(0xffeceeed),
    }),
    ColorSwatch(0x66dffdf2, {
      1: Color(0x00000000),
      2: Color(0x08f0f2f1),
      3: Color(0x12f3f5f4),
      4: Color(0x1af2fefd),
      5: Color(0x22f1fbfa),
      6: Color(0x2dedfbf4),
      7: Color(0x3cedfcf7),
      8: Color(0x57ebfdf6),
      9: Color(0x66dffdf2),
      10: Color(0x74e5fdf6),
      11: Color(0xb0f4fefb),
      12: Color(0xedfdfffe),
    }),
  ),
  Color(0x801e201f),
  Color(0xff63706b),
  Color(0xff63706b),
  Color(0xffffffff),
);

// olive color scale
const _oliveLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff898e87, {
      1: Color(0xfffcfdfc),
      2: Color(0xfff8faf8),
      3: Color(0xffeff1ef),
      4: Color(0xffe7e9e7),
      5: Color(0xffdfe2df),
      6: Color(0xffd7dad7),
      7: Color(0xffcccfcc),
      8: Color(0xffb9bcb8),
      9: Color(0xff898e87),
      10: Color(0xff7f847d),
      11: Color(0xff60655f),
      12: Color(0xff1d211c),
    }),
    ColorSwatch(0x78050f00, {
      1: Color(0x03005500),
      2: Color(0x07004900),
      3: Color(0x10002000),
      4: Color(0x18001600),
      5: Color(0x20001800),
      6: Color(0x28001400),
      7: Color(0x33000f00),
      8: Color(0x47040f00),
      9: Color(0x78050f00),
      10: Color(0x82040e00),
      11: Color(0xa0020a00),
      12: Color(0xe3010600),
    }),
  ),
  Color(0xccffffff),
  Color(0xff898e87),
  Color(0xff898e87),
  Color(0xffffffff),
);

const _oliveDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff687066, {
      1: Color(0xff111210),
      2: Color(0xff181917),
      3: Color(0xff212220),
      4: Color(0xff282a27),
      5: Color(0xff2f312e),
      6: Color(0xff383a36),
      7: Color(0xff454843),
      8: Color(0xff5c625b),
      9: Color(0xff687066),
      10: Color(0xff767d74),
      11: Color(0xffafb5ad),
      12: Color(0xffeceeec),
    }),
    ColorSwatch(0x66ebfde7, {
      1: Color(0x00000000),
      2: Color(0x08f1f2f0),
      3: Color(0x12f4f5f3),
      4: Color(0x1af3fef2),
      5: Color(0x22f2fbf1),
      6: Color(0x2cf4faed),
      7: Color(0x3bf2fced),
      8: Color(0x57edfdeb),
      9: Color(0x66ebfde7),
      10: Color(0x74f0fdec),
      11: Color(0xb0f6fef4),
      12: Color(0xedfdfffd),
    }),
  ),
  Color(0x801f201e),
  Color(0xff687066),
  Color(0xff687066),
  Color(0xffffffff),
);

// sand color scale
const _sandLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff8d8d86, {
      1: Color(0xfffdfdfc),
      2: Color(0xfff9f9f8),
      3: Color(0xfff1f0ef),
      4: Color(0xffe9e8e6),
      5: Color(0xffe2e1de),
      6: Color(0xffdad9d6),
      7: Color(0xffcfceca),
      8: Color(0xffbcbbb5),
      9: Color(0xff8d8d86),
      10: Color(0xff82827c),
      11: Color(0xff63635e),
      12: Color(0xff21201c),
    }),
    ColorSwatch(0x790f0f00, {
      1: Color(0x03555500),
      2: Color(0x07252500),
      3: Color(0x10201000),
      4: Color(0x191f1500),
      5: Color(0x211f1800),
      6: Color(0x29191300),
      7: Color(0x35191400),
      8: Color(0x4a191501),
      9: Color(0x790f0f00),
      10: Color(0x830c0c00),
      11: Color(0xa1080800),
      12: Color(0xe3060500),
    }),
  ),
  Color(0xccffffff),
  Color(0xff8d8d86),
  Color(0xff8d8d86),
  Color(0xffffffff),
);

const _sandDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff6f6d66, {
      1: Color(0xff111110),
      2: Color(0xff191918),
      3: Color(0xff222221),
      4: Color(0xff2a2a28),
      5: Color(0xff31312e),
      6: Color(0xff3b3a37),
      7: Color(0xff494844),
      8: Color(0xff62605b),
      9: Color(0xff6f6d66),
      10: Color(0xff7c7b74),
      11: Color(0xffb5b3ad),
      12: Color(0xffeeeeec),
    }),
    ColorSwatch(0x65fffae9, {
      1: Color(0x00000000),
      2: Color(0x09f4f4f3),
      3: Color(0x13f6f6f5),
      4: Color(0x1bfefef3),
      5: Color(0x23fbfbeb),
      6: Color(0x2dfffaed),
      7: Color(0x3cfffbed),
      8: Color(0x57fff9eb),
      9: Color(0x65fffae9),
      10: Color(0x73fffdee),
      11: Color(0xb0fffcf4),
      12: Color(0xedfffffd),
    }),
  ),
  Color(0x80212120),
  Color(0xff6f6d66),
  Color(0xff6f6d66),
  Color(0xffffffff),
);

// tomato color scale
const _tomatoLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffe54d2e, {
      1: Color(0xfffffcfc),
      2: Color(0xfffff8f7),
      3: Color(0xfffeebe7),
      4: Color(0xffffdcd3),
      5: Color(0xffffcdc2),
      6: Color(0xfffdbdaf),
      7: Color(0xfff5a898),
      8: Color(0xffec8e7b),
      9: Color(0xffe54d2e),
      10: Color(0xffdd4425),
      11: Color(0xffd13415),
      12: Color(0xff5c271f),
    }),
    ColorSwatch(0xd1df2600, {
      1: Color(0x03ff0000),
      2: Color(0x08ff2000),
      3: Color(0x18f52b00),
      4: Color(0x2cff3500),
      5: Color(0x3dff2e00),
      6: Color(0x50f92d00),
      7: Color(0x67e72800),
      8: Color(0x84db2500),
      9: Color(0xd1df2600),
      10: Color(0xdad72400),
      11: Color(0xeacd2200),
      12: Color(0xe0460900),
    }),
  ),
  Color(0xccfff6f5),
  Color(0xffe54d2e),
  Color(0xffe54d2e),
  Color(0xffffffff),
);

const _tomatoDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffe54d2e, {
      1: Color(0xff181111),
      2: Color(0xff1f1513),
      3: Color(0xff391714),
      4: Color(0xff4e1511),
      5: Color(0xff5e1c16),
      6: Color(0xff6e2920),
      7: Color(0xff853a2d),
      8: Color(0xffac4d39),
      9: Color(0xffe54d2e),
      10: Color(0xffec6142),
      11: Color(0xffff977d),
      12: Color(0xfffbd3cb),
    }),
    ColorSwatch(0xe4fe5431, {
      1: Color(0x08f11212),
      2: Color(0x0fff5533),
      3: Color(0x2bff3523),
      4: Color(0x42fd2011),
      5: Color(0x53fe3321),
      6: Color(0x64ff4f38),
      7: Color(0x7dfd644a),
      8: Color(0xa7fe6d4e),
      9: Color(0xe4fe5431),
      10: Color(0xebff6847),
      11: Color(0xffff977d),
      12: Color(0xfbffd6ce),
    }),
  ),
  Color(0x802d1915),
  Color(0xffe54d2e),
  Color(0xffe54d2e),
  Color(0xffffffff),
);

// red color scale
const _redLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffe5484d, {
      1: Color(0xfffffcfc),
      2: Color(0xfffff7f7),
      3: Color(0xfffeebec),
      4: Color(0xffffdbdc),
      5: Color(0xffffcdce),
      6: Color(0xfffdbdbe),
      7: Color(0xfff4a9aa),
      8: Color(0xffeb8e90),
      9: Color(0xffe5484d),
      10: Color(0xffdc3e42),
      11: Color(0xffce2c31),
      12: Color(0xff641723),
    }),
    ColorSwatch(0xb7db0007, {
      1: Color(0x03ff0000),
      2: Color(0x08ff0000),
      3: Color(0x14f3000d),
      4: Color(0x24ff0008),
      5: Color(0x32ff0006),
      6: Color(0x42f80004),
      7: Color(0x56df0003),
      8: Color(0x71d20005),
      9: Color(0xb7db0007),
      10: Color(0xc1d10005),
      11: Color(0xd3c40006),
      12: Color(0xe855000d),
    }),
  ),
  Color(0xccfff5f5),
  Color(0xffe5484d),
  Color(0xffe5484d),
  Color(0xffffffff),
);

const _redDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffe5484d, {
      1: Color(0xff191111),
      2: Color(0xff201314),
      3: Color(0xff3b1219),
      4: Color(0xff500f1c),
      5: Color(0xff611623),
      6: Color(0xff72232d),
      7: Color(0xff8c333a),
      8: Color(0xffb54548),
      9: Color(0xffe5484d),
      10: Color(0xffec5d5e),
      11: Color(0xffff9592),
      12: Color(0xffffd1d9),
    }),
    ColorSwatch(0xe4fe4e54, {
      1: Color(0x09f41212),
      2: Color(0x11f22f3e),
      3: Color(0x2dff173f),
      4: Color(0x44fe0a3b),
      5: Color(0x56ff2047),
      6: Color(0x68ff3e56),
      7: Color(0x84ff5361),
      8: Color(0xb0ff5d61),
      9: Color(0xe4fe4e54),
      10: Color(0xebff6465),
      11: Color(0xffff9592),
      12: Color(0xffffd1d9),
    }),
  ),
  Color(0x802f1517),
  Color(0xffe5484d),
  Color(0xffe5484d),
  Color(0xffffffff),
);

// ruby color scale
const _rubyLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffe54666, {
      1: Color(0xfffffcfd),
      2: Color(0xfffff7f8),
      3: Color(0xfffeeaed),
      4: Color(0xffffdce1),
      5: Color(0xffffced6),
      6: Color(0xfff8bfc8),
      7: Color(0xffefacb8),
      8: Color(0xffe592a3),
      9: Color(0xffe54666),
      10: Color(0xffdc3b5d),
      11: Color(0xffca244d),
      12: Color(0xff64172b),
    }),
    ColorSwatch(0xb9db002c, {
      1: Color(0x03ff0055),
      2: Color(0x08ff0020),
      3: Color(0x15f30025),
      4: Color(0x23ff0025),
      5: Color(0x31ff002a),
      6: Color(0x40e40024),
      7: Color(0x53ce0025),
      8: Color(0x6dc30028),
      9: Color(0xb9db002c),
      10: Color(0xc4d2002c),
      11: Color(0xdbc10030),
      12: Color(0xe8550016),
    }),
  ),
  Color(0xccfff5f6),
  Color(0xffe54666),
  Color(0xffe54666),
  Color(0xffffffff),
);

const _rubyDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffe54666, {
      1: Color(0xff191113),
      2: Color(0xff1e1517),
      3: Color(0xff3a141e),
      4: Color(0xff4e1325),
      5: Color(0xff5e1a2e),
      6: Color(0xff6f2539),
      7: Color(0xff883447),
      8: Color(0xffb3445a),
      9: Color(0xffe54666),
      10: Color(0xffec5a72),
      11: Color(0xffff949d),
      12: Color(0xfffed2e1),
    }),
    ColorSwatch(0xe4fe4c70, {
      1: Color(0x09f4124a),
      2: Color(0x0efe5a7f),
      3: Color(0x2cff235d),
      4: Color(0x42fd195e),
      5: Color(0x53fe2d6b),
      6: Color(0x65ff4476),
      7: Color(0x80ff577d),
      8: Color(0xaeff5c7c),
      9: Color(0xe4fe4c70),
      10: Color(0xebff617b),
      11: Color(0xffff949d),
      12: Color(0xfeffd3e2),
    }),
  ),
  Color(0x802b191d),
  Color(0xffe54666),
  Color(0xffe54666),
  Color(0xffffffff),
);

// crimson color scale
const _crimsonLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffe93d82, {
      1: Color(0xfffffcfd),
      2: Color(0xfffef7f9),
      3: Color(0xffffe9f0),
      4: Color(0xfffedce7),
      5: Color(0xfffacedd),
      6: Color(0xfff3bed1),
      7: Color(0xffeaacc3),
      8: Color(0xffe093b2),
      9: Color(0xffe93d82),
      10: Color(0xffdf3478),
      11: Color(0xffcb1d63),
      12: Color(0xff621639),
    }),
    ColorSwatch(0xc2e2005b, {
      1: Color(0x03ff0055),
      2: Color(0x08e00040),
      3: Color(0x16ff0052),
      4: Color(0x23f80051),
      5: Color(0x31e5004f),
      6: Color(0x41d0004b),
      7: Color(0x53bf0047),
      8: Color(0x6cb6004a),
      9: Color(0xc2e2005b),
      10: Color(0xcbd70056),
      11: Color(0xe2c4004f),
      12: Color(0xe9530026),
    }),
  ),
  Color(0xccfef5f8),
  Color(0xffe93d82),
  Color(0xffe93d82),
  Color(0xffffffff),
);

const _crimsonDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffe93d82, {
      1: Color(0xff191114),
      2: Color(0xff201318),
      3: Color(0xff381525),
      4: Color(0xff4d122f),
      5: Color(0xff5c1839),
      6: Color(0xff6d2545),
      7: Color(0xff873356),
      8: Color(0xffb0436e),
      9: Color(0xffe93d82),
      10: Color(0xffee518a),
      11: Color(0xffff92ad),
      12: Color(0xfffdd3e8),
    }),
    ColorSwatch(0xe8fe418d, {
      1: Color(0x09f41267),
      2: Color(0x11f22f7a),
      3: Color(0x2afe2a8b),
      4: Color(0x41fd1587),
      5: Color(0x51fd278f),
      6: Color(0x63fe4597),
      7: Color(0x7ffd559b),
      8: Color(0xabfe5b9b),
      9: Color(0xe8fe418d),
      10: Color(0xedff5693),
      11: Color(0xffff92ad),
      12: Color(0xfdffd5ea),
    }),
  ),
  Color(0x802f151f),
  Color(0xffe93d82),
  Color(0xffe93d82),
  Color(0xffffffff),
);

// pink color scale
const _pinkLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffd6409f, {
      1: Color(0xfffffcfe),
      2: Color(0xfffef7fb),
      3: Color(0xfffee9f5),
      4: Color(0xfffbdcef),
      5: Color(0xfff6cee7),
      6: Color(0xffefbfdd),
      7: Color(0xffe7acd0),
      8: Color(0xffdd93c2),
      9: Color(0xffd6409f),
      10: Color(0xffcf3897),
      11: Color(0xffc2298a),
      12: Color(0xff651249),
    }),
    ColorSwatch(0xbfc8007f, {
      1: Color(0x03ff00aa),
      2: Color(0x08e00080),
      3: Color(0x16f4008c),
      4: Color(0x23e2008b),
      5: Color(0x31d10083),
      6: Color(0x40c00078),
      7: Color(0x53b6006f),
      8: Color(0x6caf006f),
      9: Color(0xbfc8007f),
      10: Color(0xc7c2007a),
      11: Color(0xd6b60074),
      12: Color(0xed59003b),
    }),
  ),
  Color(0xccfef5fa),
  Color(0xffd6409f),
  Color(0xffd6409f),
  Color(0xffffffff),
);

const _pinkDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffd6409f, {
      1: Color(0xff191117),
      2: Color(0xff21121d),
      3: Color(0xff37172f),
      4: Color(0xff4b143d),
      5: Color(0xff591c47),
      6: Color(0xff692955),
      7: Color(0xff833869),
      8: Color(0xffa84885),
      9: Color(0xffd6409f),
      10: Color(0xffde51a8),
      11: Color(0xffff8dcc),
      12: Color(0xfffdd1ea),
    }),
    ColorSwatch(0xd4fe49bc, {
      1: Color(0x09f412bc),
      2: Color(0x12f420bb),
      3: Color(0x29fe37cc),
      4: Color(0x3ffc1ec4),
      5: Color(0x4efd35c2),
      6: Color(0x5ffd51c7),
      7: Color(0x7bfd62c8),
      8: Color(0xa2ff68c8),
      9: Color(0xd4fe49bc),
      10: Color(0xdcff5cc0),
      11: Color(0xffff8dcc),
      12: Color(0xfdffd3ec),
    }),
  ),
  Color(0x80311329),
  Color(0xffd6409f),
  Color(0xffd6409f),
  Color(0xffffffff),
);

// plum color scale
const _plumLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffab4aba, {
      1: Color(0xfffefcff),
      2: Color(0xfffdf7fd),
      3: Color(0xfffbebfb),
      4: Color(0xfff7def8),
      5: Color(0xfff2d1f3),
      6: Color(0xffe9c2ec),
      7: Color(0xffdeade3),
      8: Color(0xffcf91d8),
      9: Color(0xffab4aba),
      10: Color(0xffa144af),
      11: Color(0xff953ea3),
      12: Color(0xff53195d),
    }),
    ColorSwatch(0xb589009e, {
      1: Color(0x03aa00ff),
      2: Color(0x08c000c0),
      3: Color(0x14cc00cc),
      4: Color(0x21c200c9),
      5: Color(0x2eb700bd),
      6: Color(0x3da400b0),
      7: Color(0x529900a8),
      8: Color(0x6e9000a5),
      9: Color(0xb589009e),
      10: Color(0xbb7f0092),
      11: Color(0xc1730086),
      12: Color(0xe640004b),
    }),
  ),
  Color(0xccfdf5fd),
  Color(0xffab4aba),
  Color(0xffab4aba),
  Color(0xffffffff),
);

const _plumDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffab4aba, {
      1: Color(0xff181118),
      2: Color(0xff201320),
      3: Color(0xff351a35),
      4: Color(0xff451d47),
      5: Color(0xff512454),
      6: Color(0xff5e3061),
      7: Color(0xff734079),
      8: Color(0xff92549c),
      9: Color(0xffab4aba),
      10: Color(0xffb658c4),
      11: Color(0xffe796f3),
      12: Color(0xfff4d4f4),
    }),
    ColorSwatch(0xb6e961fe, {
      1: Color(0x08f112f1),
      2: Color(0x11f22ff2),
      3: Color(0x27fd4cfd),
      4: Color(0x3af646ff),
      5: Color(0x48f455ff),
      6: Color(0x56f66dff),
      7: Color(0x70f07cfd),
      8: Color(0x95ee84ff),
      9: Color(0xb6e961fe),
      10: Color(0xc0ed70ff),
      11: Color(0xf3f19cfe),
      12: Color(0xf4feddfe),
    }),
  ),
  Color(0x802f152f),
  Color(0xffab4aba),
  Color(0xffab4aba),
  Color(0xffffffff),
);

// purple color scale
const _purpleLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff8e4ec6, {
      1: Color(0xfffefcfe),
      2: Color(0xfffbf7fe),
      3: Color(0xfff7edfe),
      4: Color(0xfff2e2fc),
      5: Color(0xffead5f9),
      6: Color(0xffe0c4f4),
      7: Color(0xffd1afec),
      8: Color(0xffbe93e4),
      9: Color(0xff8e4ec6),
      10: Color(0xff8347b9),
      11: Color(0xff8145b5),
      12: Color(0xff402060),
    }),
    ColorSwatch(0xb15c00ad, {
      1: Color(0x03aa00aa),
      2: Color(0x088000e0),
      3: Color(0x128e00f1),
      4: Color(0x1d8d00e5),
      5: Color(0x2a8000db),
      6: Color(0x3b7a01d0),
      7: Color(0x506d00c3),
      8: Color(0x6c6600c0),
      9: Color(0xb15c00ad),
      10: Color(0xb853009e),
      11: Color(0xba52009a),
      12: Color(0xdf250049),
    }),
  ),
  Color(0xccfaf5fe),
  Color(0xff8e4ec6),
  Color(0xff8e4ec6),
  Color(0xffffffff),
);

const _purpleDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff8e4ec6, {
      1: Color(0xff18111b),
      2: Color(0xff1e1523),
      3: Color(0xff301c3b),
      4: Color(0xff3d224e),
      5: Color(0xff48295c),
      6: Color(0xff54346b),
      7: Color(0xff664282),
      8: Color(0xff8457aa),
      9: Color(0xff8e4ec6),
      10: Color(0xff9a5cd0),
      11: Color(0xffd19dff),
      12: Color(0xffecd9fa),
    }),
    ColorSwatch(0xc2b661ff, {
      1: Color(0x0bb412f9),
      2: Color(0x14b744f7),
      3: Color(0x2dc150ff),
      4: Color(0x42bb53fd),
      5: Color(0x51be5cfd),
      6: Color(0x61c16dfd),
      7: Color(0x7ac378fd),
      8: Color(0xa4c47eff),
      9: Color(0xc2b661ff),
      10: Color(0xcdbc6fff),
      11: Color(0xffd19dff),
      12: Color(0xfaf1ddff),
    }),
  ),
  Color(0x802b1735),
  Color(0xff8e4ec6),
  Color(0xff8e4ec6),
  Color(0xffffffff),
);

// violet color scale
const _violetLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff6e56cf, {
      1: Color(0xfffdfcfe),
      2: Color(0xfffaf8ff),
      3: Color(0xfff4f0fe),
      4: Color(0xffebe4ff),
      5: Color(0xffe1d9ff),
      6: Color(0xffd4cafe),
      7: Color(0xffc2b5f5),
      8: Color(0xffaa99ec),
      9: Color(0xff6e56cf),
      10: Color(0xff654dc4),
      11: Color(0xff6550b9),
      12: Color(0xff2f265f),
    }),
    ColorSwatch(0xa92400b7, {
      1: Color(0x035500aa),
      2: Color(0x074900ff),
      3: Color(0x0f4400ee),
      4: Color(0x1b4300ff),
      5: Color(0x263600ff),
      6: Color(0x353100fb),
      7: Color(0x4a2d01dd),
      8: Color(0x662b00d0),
      9: Color(0xa92400b7),
      10: Color(0xb22300ab),
      11: Color(0xaf1f0099),
      12: Color(0xd90b0043),
    }),
  ),
  Color(0xccf9f6ff),
  Color(0xff6e56cf),
  Color(0xff6e56cf),
  Color(0xffffffff),
);

const _violetDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff6e56cf, {
      1: Color(0xff14121f),
      2: Color(0xff1b1525),
      3: Color(0xff291f43),
      4: Color(0xff33255b),
      5: Color(0xff3c2e69),
      6: Color(0xff473876),
      7: Color(0xff56468b),
      8: Color(0xff6958ad),
      9: Color(0xff6e56cf),
      10: Color(0xff7d66d9),
      11: Color(0xffbaa7ff),
      12: Color(0xffe2ddfe),
    }),
    ColorSwatch(0xcc8668ff, {
      1: Color(0x0f4422ff),
      2: Color(0x16853ff9),
      3: Color(0x368354fe),
      4: Color(0x507d51fd),
      5: Color(0x5f845ffd),
      6: Color(0x6d8f6cfd),
      7: Color(0x839879ff),
      8: Color(0xa8977dfe),
      9: Color(0xcc8668ff),
      10: Color(0xd79176fe),
      11: Color(0xffbaa7ff),
      12: Color(0xfee3deff),
    }),
  ),
  Color(0x80251939),
  Color(0xff6e56cf),
  Color(0xff6e56cf),
  Color(0xffffffff),
);

// iris color scale
const _irisLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff5b5bd6, {
      1: Color(0xfffdfdff),
      2: Color(0xfff8f8ff),
      3: Color(0xfff0f1fe),
      4: Color(0xffe6e7ff),
      5: Color(0xffdadcff),
      6: Color(0xffcbcdff),
      7: Color(0xffb8baf8),
      8: Color(0xff9b9ef0),
      9: Color(0xff5b5bd6),
      10: Color(0xff5151cd),
      11: Color(0xff5753c6),
      12: Color(0xff272962),
    }),
    ColorSwatch(0xa40000c0, {
      1: Color(0x020000ff),
      2: Color(0x070000ff),
      3: Color(0x0f0011ee),
      4: Color(0x19000bff),
      5: Color(0x25000eff),
      6: Color(0x34000aff),
      7: Color(0x470008e6),
      8: Color(0x640008d9),
      9: Color(0xa40000c0),
      10: Color(0xae0000b6),
      11: Color(0xac0600ab),
      12: Color(0xd8000246),
    }),
  ),
  Color(0xccf6f6ff),
  Color(0xff5b5bd6),
  Color(0xff5b5bd6),
  Color(0xffffffff),
);

const _irisDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff5b5bd6, {
      1: Color(0xff13131e),
      2: Color(0xff171625),
      3: Color(0xff202248),
      4: Color(0xff262a65),
      5: Color(0xff303374),
      6: Color(0xff3d3e82),
      7: Color(0xff4a4a95),
      8: Color(0xff5958b1),
      9: Color(0xff5b5bd6),
      10: Color(0xff6e6ade),
      11: Color(0xffb1a9ff),
      12: Color(0xffe0dffe),
    }),
    ColorSwatch(0xd46a6afe, {
      1: Color(0x0e3636fe),
      2: Color(0x16564bf9),
      3: Color(0x3b525bff),
      4: Color(0x5a4d58ff),
      5: Color(0x6b5b62fd),
      6: Color(0x7a6d6ffd),
      7: Color(0x8e7777fe),
      8: Color(0xac7b7afe),
      9: Color(0xd46a6afe),
      10: Color(0xdc7d79ff),
      11: Color(0xffb1a9ff),
      12: Color(0xfee1e0ff),
    }),
  ),
  Color(0x801d1b39),
  Color(0xff5b5bd6),
  Color(0xff5b5bd6),
  Color(0xffffffff),
);

// indigo color scale
const _indigoLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff3e63dd, {
      1: Color(0xfffdfdfe),
      2: Color(0xfff7f9ff),
      3: Color(0xffedf2fe),
      4: Color(0xffe1e9ff),
      5: Color(0xffd2deff),
      6: Color(0xffc1d0ff),
      7: Color(0xffabbdf9),
      8: Color(0xff8da4ef),
      9: Color(0xff3e63dd),
      10: Color(0xff3358d4),
      11: Color(0xff3a5bc7),
      12: Color(0xff1f2d5c),
    }),
    ColorSwatch(0xc10031d2, {
      1: Color(0x02000080),
      2: Color(0x080040ff),
      3: Color(0x120047f1),
      4: Color(0x1e0044ff),
      5: Color(0x2d0044ff),
      6: Color(0x3e003eff),
      7: Color(0x540037ed),
      8: Color(0x720034dc),
      9: Color(0xc10031d2),
      10: Color(0xcc002ec9),
      11: Color(0xc5002bb7),
      12: Color(0xe0001046),
    }),
  ),
  Color(0xccf5f8ff),
  Color(0xff3e63dd),
  Color(0xff3e63dd),
  Color(0xffffffff),
);

const _indigoDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff3e63dd, {
      1: Color(0xff11131f),
      2: Color(0xff141726),
      3: Color(0xff182449),
      4: Color(0xff1d2e62),
      5: Color(0xff253974),
      6: Color(0xff304384),
      7: Color(0xff3a4f97),
      8: Color(0xff435db1),
      9: Color(0xff3e63dd),
      10: Color(0xff5472e4),
      11: Color(0xff9eb1ff),
      12: Color(0xffd6e1ff),
    }),
    ColorSwatch(0xdb4671ff, {
      1: Color(0x0f1133ff),
      2: Color(0x173354fa),
      3: Color(0x3c2f62ff),
      4: Color(0x573566ff),
      5: Color(0x6b4171fd),
      6: Color(0x7c5178fd),
      7: Color(0x905a7fff),
      8: Color(0xac5b81fe),
      9: Color(0xdb4671ff),
      10: Color(0xe35c7efe),
      11: Color(0xff9eb1ff),
      12: Color(0xffd6e1ff),
    }),
  ),
  Color(0x80171d3b),
  Color(0xff3e63dd),
  Color(0xff3e63dd),
  Color(0xffffffff),
);

// blue color scale
const _blueLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff0090ff, {
      1: Color(0xfffbfdff),
      2: Color(0xfff4faff),
      3: Color(0xffe6f4fe),
      4: Color(0xffd5efff),
      5: Color(0xffc2e5ff),
      6: Color(0xffacd8fc),
      7: Color(0xff8ec8f6),
      8: Color(0xff5eb1ef),
      9: Color(0xff0090ff),
      10: Color(0xff0588f0),
      11: Color(0xff0d74ce),
      12: Color(0xff113264),
    }),
    ColorSwatch(0xff0090ff, {
      1: Color(0x040080ff),
      2: Color(0x0b008cff),
      3: Color(0x19008ff5),
      4: Color(0x2a009eff),
      5: Color(0x3d0093ff),
      6: Color(0x530088f6),
      7: Color(0x710083eb),
      8: Color(0xa10084e6),
      9: Color(0xff0090ff),
      10: Color(0xfa0086f0),
      11: Color(0xf2006dcb),
      12: Color(0xee002359),
    }),
  ),
  Color(0xccf1f9ff),
  Color(0xff0090ff),
  Color(0xff0090ff),
  Color(0xffffffff),
);

const _blueDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff0090ff, {
      1: Color(0xff0d1520),
      2: Color(0xff111927),
      3: Color(0xff0d2847),
      4: Color(0xff003362),
      5: Color(0xff004074),
      6: Color(0xff104d87),
      7: Color(0xff205d9e),
      8: Color(0xff2870bd),
      9: Color(0xff0090ff),
      10: Color(0xff3b9eff),
      11: Color(0xff70b8ff),
      12: Color(0xffc2e6ff),
    }),
    ColorSwatch(0xff0090ff, {
      1: Color(0x11004df2),
      2: Color(0x181166fb),
      3: Color(0x3a0077ff),
      4: Color(0x570075ff),
      5: Color(0x6b0081fd),
      6: Color(0x7f0f89fd),
      7: Color(0x982a91fe),
      8: Color(0xb93094fe),
      9: Color(0xff0090ff),
      10: Color(0xff3b9eff),
      11: Color(0xff70b8ff),
      12: Color(0xffc2e6ff),
    }),
  ),
  Color(0x8011213d),
  Color(0xff0090ff),
  Color(0xff0090ff),
  Color(0xffffffff),
);

// cyan color scale
const _cyanLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff00a2c7, {
      1: Color(0xfffafdfe),
      2: Color(0xfff2fafb),
      3: Color(0xffdef7f9),
      4: Color(0xffcaf1f6),
      5: Color(0xffb5e9f0),
      6: Color(0xff9ddde7),
      7: Color(0xff7dcedc),
      8: Color(0xff3db9cf),
      9: Color(0xff00a2c7),
      10: Color(0xff0797b9),
      11: Color(0xff107d98),
      12: Color(0xff0d3c48),
    }),
    ColorSwatch(0xff00a2c7, {
      1: Color(0x050099cc),
      2: Color(0x0d009db1),
      3: Color(0x2100c2d1),
      4: Color(0x3500bcd4),
      5: Color(0x4a01b4cc),
      6: Color(0x6200a7c1),
      7: Color(0x82009fbb),
      8: Color(0xc200a3c0),
      9: Color(0xff00a2c7),
      10: Color(0xf80094b7),
      11: Color(0xef007491),
      12: Color(0xf200323e),
    }),
  ),
  Color(0xcceff9fa),
  Color(0xff00a2c7),
  Color(0xff00a2c7),
  Color(0xffffffff),
);

const _cyanDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff00a2c7, {
      1: Color(0xff0b161a),
      2: Color(0xff101b20),
      3: Color(0xff082c36),
      4: Color(0xff003848),
      5: Color(0xff004558),
      6: Color(0xff045468),
      7: Color(0xff12677e),
      8: Color(0xff11809c),
      9: Color(0xff00a2c7),
      10: Color(0xff23afd0),
      11: Color(0xff4ccce6),
      12: Color(0xffb6ecf7),
    }),
    ColorSwatch(0xc300cfff, {
      1: Color(0x0a0091f7),
      2: Color(0x1102a7f2),
      3: Color(0x2800befd),
      4: Color(0x3b00baff),
      5: Color(0x4d00befd),
      6: Color(0x5e00c7fd),
      7: Color(0x7514cdff),
      8: Color(0x9511cfff),
      9: Color(0xc300cfff),
      10: Color(0xcd28d6ff),
      11: Color(0xe552e1fe),
      12: Color(0xf7bbf3fe),
    }),
  ),
  Color(0x8011252d),
  Color(0xff00a2c7),
  Color(0xff00a2c7),
  Color(0xffffffff),
);

// teal color scale
const _tealLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff12a594, {
      1: Color(0xfffafefd),
      2: Color(0xfff3fbf9),
      3: Color(0xffe0f8f3),
      4: Color(0xffccf3ea),
      5: Color(0xffb8eae0),
      6: Color(0xffa1ded2),
      7: Color(0xff83cdc1),
      8: Color(0xff53b9ab),
      9: Color(0xff12a594),
      10: Color(0xff0d9b8a),
      11: Color(0xff008573),
      12: Color(0xff0d3d38),
    }),
    ColorSwatch(0xed009e8c, {
      1: Color(0x0500cc99),
      2: Color(0x0c00aa80),
      3: Color(0x1f00c69d),
      4: Color(0x3300c396),
      5: Color(0x4700b490),
      6: Color(0x5e00a685),
      7: Color(0x7c009980),
      8: Color(0xac009783),
      9: Color(0xed009e8c),
      10: Color(0xf2009684),
      11: Color(0xff008573),
      12: Color(0xf200332d),
    }),
  ),
  Color(0xccf0faf8),
  Color(0xff12a594),
  Color(0xff12a594),
  Color(0xffffffff),
);

const _tealDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff12a594, {
      1: Color(0xff0d1514),
      2: Color(0xff111c1b),
      3: Color(0xff0d2d2a),
      4: Color(0xff023b37),
      5: Color(0xff084843),
      6: Color(0xff145750),
      7: Color(0xff1c6961),
      8: Color(0xff207e73),
      9: Color(0xff12a594),
      10: Color(0xff0eb39e),
      11: Color(0xff0bd8b6),
      12: Color(0xffadf0dd),
    }),
    ColorSwatch(0x9f13ffe4, {
      1: Color(0x0500deab),
      2: Color(0x0c12fbe6),
      3: Color(0x1e00ffe6),
      4: Color(0x2d00ffe9),
      5: Color(0x3b00ffea),
      6: Color(0x4b1cffe8),
      7: Color(0x5f2efde8),
      8: Color(0x7532ffe7),
      9: Color(0x9f13ffe4),
      10: Color(0xae0dffe0),
      11: Color(0xd60afed5),
      12: Color(0xefb8ffeb),
    }),
  ),
  Color(0x80132725),
  Color(0xff12a594),
  Color(0xff12a594),
  Color(0xffffffff),
);

// jade color scale
const _jadeLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff29a383, {
      1: Color(0xfffbfefd),
      2: Color(0xfff4fbf7),
      3: Color(0xffe6f7ed),
      4: Color(0xffd6f1e3),
      5: Color(0xffc3e9d7),
      6: Color(0xffacdec8),
      7: Color(0xff8bceb6),
      8: Color(0xff56ba9f),
      9: Color(0xff29a383),
      10: Color(0xff26997b),
      11: Color(0xff208368),
      12: Color(0xff1d3b31),
    }),
    ColorSwatch(0xd600916b, {
      1: Color(0x0400c080),
      2: Color(0x0b00a346),
      3: Color(0x1900ae48),
      4: Color(0x2900a851),
      5: Color(0x3c00a255),
      6: Color(0x53009a57),
      7: Color(0x7400945f),
      8: Color(0xa900976e),
      9: Color(0xd600916b),
      10: Color(0xd9008764),
      11: Color(0xdf007152),
      12: Color(0xe2002217),
    }),
  ),
  Color(0xccf1faf5),
  Color(0xff29a383),
  Color(0xff29a383),
  Color(0xffffffff),
);

const _jadeDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff29a383, {
      1: Color(0xff0d1512),
      2: Color(0xff121c18),
      3: Color(0xff0f2e22),
      4: Color(0xff0b3b2c),
      5: Color(0xff114837),
      6: Color(0xff1b5745),
      7: Color(0xff246854),
      8: Color(0xff2a7e68),
      9: Color(0xff29a383),
      10: Color(0xff27b08b),
      11: Color(0xff1fd8a4),
      12: Color(0xffadf0d4),
    }),
    ColorSwatch(0x9d38feca, {
      1: Color(0x0500de45),
      2: Color(0x0c27fba6),
      3: Color(0x2002f999),
      4: Color(0x2d00ffaa),
      5: Color(0x3b11ffb6),
      6: Color(0x4b34ffc2),
      7: Color(0x5e45fdc7),
      8: Color(0x7548ffcf),
      9: Color(0x9d38feca),
      10: Color(0xab31fec7),
      11: Color(0xd621fec0),
      12: Color(0xefb8ffe1),
    }),
  ),
  Color(0x8013271f),
  Color(0xff29a383),
  Color(0xff29a383),
  Color(0xffffffff),
);

// green color scale
const _greenLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff30a46c, {
      1: Color(0xfffbfefc),
      2: Color(0xfff4fbf6),
      3: Color(0xffe6f6eb),
      4: Color(0xffd6f1df),
      5: Color(0xffc4e8d1),
      6: Color(0xffadddc0),
      7: Color(0xff8eceaa),
      8: Color(0xff5bb98b),
      9: Color(0xff30a46c),
      10: Color(0xff2b9a66),
      11: Color(0xff218358),
      12: Color(0xff193b2d),
    }),
    ColorSwatch(0xcf008f4a, {
      1: Color(0x0400c040),
      2: Color(0x0b00a32f),
      3: Color(0x1900a433),
      4: Color(0x2900a838),
      5: Color(0x3b019c39),
      6: Color(0x5200963c),
      7: Color(0x71009140),
      8: Color(0xa400924b),
      9: Color(0xcf008f4a),
      10: Color(0xd4008647),
      11: Color(0xde00713f),
      12: Color(0xe6002616),
    }),
  ),
  Color(0xccf1faf4),
  Color(0xff30a46c),
  Color(0xff30a46c),
  Color(0xffffffff),
);

const _greenDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff30a46c, {
      1: Color(0xff0e1512),
      2: Color(0xff121b17),
      3: Color(0xff132d21),
      4: Color(0xff113b29),
      5: Color(0xff174933),
      6: Color(0xff20573e),
      7: Color(0xff28684a),
      8: Color(0xff2f7c57),
      9: Color(0xff30a46c),
      10: Color(0xff33b074),
      11: Color(0xff3dd68c),
      12: Color(0xffb1f1cb),
    }),
    ColorSwatch(0x9e44ffa4, {
      1: Color(0x0500de45),
      2: Color(0x0b29f99d),
      3: Color(0x1e22ff99),
      4: Color(0x2d11ff99),
      5: Color(0x3c2bffa2),
      6: Color(0x4b44ffaa),
      7: Color(0x5e50fdac),
      8: Color(0x7354ffad),
      9: Color(0x9e44ffa4),
      10: Color(0xab43fea4),
      11: Color(0xd446fea5),
      12: Color(0xf0bbffd7),
    }),
  ),
  Color(0x8015251d),
  Color(0xff30a46c),
  Color(0xff30a46c),
  Color(0xffffffff),
);

// grass color scale
const _grassLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff46a758, {
      1: Color(0xfffbfefb),
      2: Color(0xfff5fbf5),
      3: Color(0xffe9f6e9),
      4: Color(0xffdaf1db),
      5: Color(0xffc9e8ca),
      6: Color(0xffb2ddb5),
      7: Color(0xff94ce9a),
      8: Color(0xff65ba74),
      9: Color(0xff46a758),
      10: Color(0xff3e9b4f),
      11: Color(0xff2a7e3b),
      12: Color(0xff203c25),
    }),
    ColorSwatch(0xb9008619, {
      1: Color(0x0400c000),
      2: Color(0x0a009900),
      3: Color(0x16009700),
      4: Color(0x25009f07),
      5: Color(0x36009305),
      6: Color(0x4d008f0a),
      7: Color(0x6b018b0f),
      8: Color(0x9a008d19),
      9: Color(0xb9008619),
      10: Color(0xc1007b17),
      11: Color(0xd5006514),
      12: Color(0xdf002006),
    }),
  ),
  Color(0xccf3faf3),
  Color(0xff46a758),
  Color(0xff46a758),
  Color(0xffffffff),
);

const _grassDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff46a758, {
      1: Color(0xff0e1511),
      2: Color(0xff141a15),
      3: Color(0xff1b2a1e),
      4: Color(0xff1d3a24),
      5: Color(0xff25482d),
      6: Color(0xff2d5736),
      7: Color(0xff366740),
      8: Color(0xff3e7949),
      9: Color(0xff46a758),
      10: Color(0xff53b365),
      11: Color(0xff71d083),
      12: Color(0xffc2f0c2),
    }),
    ColorSwatch(0xa165ff82, {
      1: Color(0x0500de12),
      2: Color(0x0a5ef778),
      3: Color(0x1b70fe8c),
      4: Color(0x2c57ff80),
      5: Color(0x3b68ff8b),
      6: Color(0x4b71ff8f),
      7: Color(0x5d77fd92),
      8: Color(0x7077fd90),
      9: Color(0xa165ff82),
      10: Color(0xae72ff8d),
      11: Color(0xcd89ff9f),
      12: Color(0xefceffce),
    }),
  ),
  Color(0x8019231b),
  Color(0xff46a758),
  Color(0xff46a758),
  Color(0xffffffff),
);

// bronze color scale
const _bronzeLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffa18072, {
      1: Color(0xfffdfcfc),
      2: Color(0xfffdf7f5),
      3: Color(0xfff6edea),
      4: Color(0xffefe4df),
      5: Color(0xffe7d9d3),
      6: Color(0xffdfcdc5),
      7: Color(0xffd3bcb3),
      8: Color(0xffc2a499),
      9: Color(0xffa18072),
      10: Color(0xff957468),
      11: Color(0xff7d5e54),
      12: Color(0xff43302b),
    }),
    ColorSwatch(0x8d551a00, {
      1: Color(0x03550000),
      2: Color(0x0acc3300),
      3: Color(0x15922500),
      4: Color(0x20802800),
      5: Color(0x2c742300),
      6: Color(0x3a732400),
      7: Color(0x4c6c1f00),
      8: Color(0x66671c00),
      9: Color(0x8d551a00),
      10: Color(0x974c1500),
      11: Color(0xab3d0f00),
      12: Color(0xd41d0600),
    }),
  ),
  Color(0xccfdf5f3),
  Color(0xffa18072),
  Color(0xffa18072),
  Color(0xffffffff),
);

const _bronzeDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffa18072, {
      1: Color(0xff141110),
      2: Color(0xff1c1917),
      3: Color(0xff262220),
      4: Color(0xff302a27),
      5: Color(0xff3b3330),
      6: Color(0xff493e3a),
      7: Color(0xff5a4c47),
      8: Color(0xff6f5f58),
      9: Color(0xffa18072),
      10: Color(0xffae8c7e),
      11: Color(0xffd4b3a5),
      12: Color(0xffede0d9),
    }),
    ColorSwatch(0x9bfec7b0, {
      1: Color(0x04d11100),
      2: Color(0x0cfbbc91),
      3: Color(0x17faceb8),
      4: Color(0x22facdb6),
      5: Color(0x2dffd2c1),
      6: Color(0x3cffd1c0),
      7: Color(0x4ffdd0c0),
      8: Color(0x65ffd6c5),
      9: Color(0x9bfec7b0),
      10: Color(0xa9fecab5),
      11: Color(0xd1ffd7c6),
      12: Color(0xecfff1e9),
    }),
  ),
  Color(0x8027211d),
  Color(0xffa18072),
  Color(0xffa18072),
  Color(0xffffffff),
);

// gold color scale
const _goldLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff978365, {
      1: Color(0xfffdfdfc),
      2: Color(0xfffaf9f2),
      3: Color(0xfff2f0e7),
      4: Color(0xffeae6db),
      5: Color(0xffe1dccf),
      6: Color(0xffd8d0bf),
      7: Color(0xffcbc0aa),
      8: Color(0xffb9a88d),
      9: Color(0xff978365),
      10: Color(0xff8c7a5e),
      11: Color(0xff71624b),
      12: Color(0xff3b352b),
    }),
    ColorSwatch(0x9a533200, {
      1: Color(0x03555500),
      2: Color(0x0d9d8a00),
      3: Color(0x18756000),
      4: Color(0x246b4e00),
      5: Color(0x30604600),
      6: Color(0x40644400),
      7: Color(0x55634200),
      8: Color(0x72633d00),
      9: Color(0x9a533200),
      10: Color(0xa1492d00),
      11: Color(0xb4362100),
      12: Color(0xd4130c00),
    }),
  ),
  Color(0xccf9f8ef),
  Color(0xff978365),
  Color(0xff978365),
  Color(0xffffffff),
);

const _goldDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff978365, {
      1: Color(0xff121211),
      2: Color(0xff1b1a17),
      3: Color(0xff24231f),
      4: Color(0xff2d2b26),
      5: Color(0xff38352e),
      6: Color(0xff444039),
      7: Color(0xff544f46),
      8: Color(0xff696256),
      9: Color(0xff978365),
      10: Color(0xffa39073),
      11: Color(0xffcbb99f),
      12: Color(0xffe8e2d9),
    }),
    ColorSwatch(0x90ffdba6, {
      1: Color(0x02919111),
      2: Color(0x0bf9e29d),
      3: Color(0x15f8ecbb),
      4: Color(0x1effeec4),
      5: Color(0x2afeecc2),
      6: Color(0x37feebcb),
      7: Color(0x48ffedcd),
      8: Color(0x5ffdeaca),
      9: Color(0x90ffdba6),
      10: Color(0x9dfedfb0),
      11: Color(0xc8fee7c6),
      12: Color(0xe7fef7ed),
    }),
  ),
  Color(0x8025231d),
  Color(0xff978365),
  Color(0xff978365),
  Color(0xffffffff),
);

// brown color scale
const _brownLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffad7f58, {
      1: Color(0xfffefdfc),
      2: Color(0xfffcf9f6),
      3: Color(0xfff6eee7),
      4: Color(0xfff0e4d9),
      5: Color(0xffebdaca),
      6: Color(0xffe4cdb7),
      7: Color(0xffdcbc9f),
      8: Color(0xffcea37e),
      9: Color(0xffad7f58),
      10: Color(0xffa07553),
      11: Color(0xff815e46),
      12: Color(0xff3e332e),
    }),
    ColorSwatch(0xa7823c00, {
      1: Color(0x03aa5500),
      2: Color(0x09aa5500),
      3: Color(0x18a04b00),
      4: Color(0x269b4a00),
      5: Color(0x359f4d00),
      6: Color(0x48a04e00),
      7: Color(0x60a34e00),
      8: Color(0x819f4a00),
      9: Color(0xa7823c00),
      10: Color(0xac723300),
      11: Color(0xb9522100),
      12: Color(0xd1140600),
    }),
  ),
  Color(0xccfbf8f4),
  Color(0xffad7f58),
  Color(0xffad7f58),
  Color(0xffffffff),
);

const _brownDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffad7f58, {
      1: Color(0xff12110f),
      2: Color(0xff1c1816),
      3: Color(0xff28211d),
      4: Color(0xff322922),
      5: Color(0xff3e3128),
      6: Color(0xff4d3c2f),
      7: Color(0xff614a39),
      8: Color(0xff7c5f46),
      9: Color(0xffad7f58),
      10: Color(0xffb88c67),
      11: Color(0xffdbb594),
      12: Color(0xfff2e1ca),
    }),
    ColorSwatch(0xa8feb87d, {
      1: Color(0x02911100),
      2: Color(0x0cfba67c),
      3: Color(0x19fcb58c),
      4: Color(0x24fbbb8a),
      5: Color(0x31fcb889),
      6: Color(0x41fdba87),
      7: Color(0x56ffbb88),
      8: Color(0x73ffbe87),
      9: Color(0xa8feb87d),
      10: Color(0xb3ffc18c),
      11: Color(0xd9fed1aa),
      12: Color(0xf2feecd4),
    }),
  ),
  Color(0x80271f1b),
  Color(0xffad7f58),
  Color(0xffad7f58),
  Color(0xffffffff),
);

// orange color scale
const _orangeLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xfff76b15, {
      1: Color(0xfffefcfb),
      2: Color(0xfffff7ed),
      3: Color(0xffffefd6),
      4: Color(0xffffdfb5),
      5: Color(0xffffd19a),
      6: Color(0xffffc182),
      7: Color(0xfff5ae73),
      8: Color(0xffec9455),
      9: Color(0xfff76b15),
      10: Color(0xffef5f00),
      11: Color(0xffcc4e00),
      12: Color(0xff582d1d),
    }),
    ColorSwatch(0xeaf65e00, {
      1: Color(0x04c04000),
      2: Color(0x12ff8e00),
      3: Color(0x29ff9c00),
      4: Color(0x4aff9101),
      5: Color(0x65ff8b00),
      6: Color(0x7dff8100),
      7: Color(0x8ced6c00),
      8: Color(0xaae35f00),
      9: Color(0xeaf65e00),
      10: Color(0xffef5f00),
      11: Color(0xffcc4e00),
      12: Color(0xe2431200),
    }),
  ),
  Color(0xccfff5e9),
  Color(0xfff76b15),
  Color(0xfff76b15),
  Color(0xffffffff),
);

const _orangeDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xfff76b15, {
      1: Color(0xff17120e),
      2: Color(0xff1e160f),
      3: Color(0xff331e0b),
      4: Color(0xff462100),
      5: Color(0xff562800),
      6: Color(0xff66350c),
      7: Color(0xff7e451d),
      8: Color(0xffa35829),
      9: Color(0xfff76b15),
      10: Color(0xffff801f),
      11: Color(0xffffa057),
      12: Color(0xffffe0c2),
    }),
    ColorSwatch(0xf7fe6d15, {
      1: Color(0x07ec3600),
      2: Color(0x0efe6d00),
      3: Color(0x25fb6a00),
      4: Color(0x39ff5900),
      5: Color(0x4aff6100),
      6: Color(0x5cfd7504),
      7: Color(0x75ff832c),
      8: Color(0x9dfe8438),
      9: Color(0xf7fe6d15),
      10: Color(0xffff801f),
      11: Color(0xffffa057),
      12: Color(0xffffe0c2),
    }),
  ),
  Color(0x80271d13),
  Color(0xfff76b15),
  Color(0xfff76b15),
  Color(0xffffffff),
);

// amber color scale
const _amberLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffffc53d, {
      1: Color(0xfffefdfb),
      2: Color(0xfffefbe9),
      3: Color(0xfffff7c2),
      4: Color(0xffffee9c),
      5: Color(0xfffbe577),
      6: Color(0xfff3d673),
      7: Color(0xffe9c162),
      8: Color(0xffe2a336),
      9: Color(0xffffc53d),
      10: Color(0xffffba18),
      11: Color(0xffab6400),
      12: Color(0xff4f3422),
    }),
    ColorSwatch(0xc2ffb300, {
      1: Color(0x04c08000),
      2: Color(0x16f4d100),
      3: Color(0x3dffde00),
      4: Color(0x63ffd400),
      5: Color(0x88f8cf00),
      6: Color(0x8ceab500),
      7: Color(0x9ddc9b00),
      8: Color(0xc9da8a00),
      9: Color(0xc2ffb300),
      10: Color(0xe7ffb300),
      11: Color(0xffab6400),
      12: Color(0xdd341500),
    }),
  ),
  Color(0xccfefae4),
  Color(0xffffc53d),
  Color(0xffffc53d),
  Color(0xff21201c),
);

const _amberDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffffc53d, {
      1: Color(0xff16120c),
      2: Color(0xff1d180f),
      3: Color(0xff302008),
      4: Color(0xff3f2700),
      5: Color(0xff4d3000),
      6: Color(0xff5c3d05),
      7: Color(0xff714f19),
      8: Color(0xff8f6424),
      9: Color(0xffffc53d),
      10: Color(0xffffd60a),
      11: Color(0xffffca16),
      12: Color(0xffffe7b3),
    }),
    ColorSwatch(0xffffc53d, {
      1: Color(0x06e63c00),
      2: Color(0x0dfd9b00),
      3: Color(0x22fa8200),
      4: Color(0x32fc8200),
      5: Color(0x41fd8b00),
      6: Color(0x51fd9b00),
      7: Color(0x67ffab25),
      8: Color(0x87ffae35),
      9: Color(0xffffc53d),
      10: Color(0xffffd60a),
      11: Color(0xffffca16),
      12: Color(0xffffe7b3),
    }),
  ),
  Color(0x80271f13),
  Color(0xffffc53d),
  Color(0xffe2ac37),
  Color(0xff21201c),
);

// yellow color scale
const _yellowLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffffe629, {
      1: Color(0xfffdfdf9),
      2: Color(0xfffefce9),
      3: Color(0xfffffab8),
      4: Color(0xfffff394),
      5: Color(0xffffe770),
      6: Color(0xfff3d768),
      7: Color(0xffe4c767),
      8: Color(0xffd5ae39),
      9: Color(0xffffe629),
      10: Color(0xffffdc00),
      11: Color(0xff9e6c00),
      12: Color(0xff473b1f),
    }),
    ColorSwatch(0xd6ffe100, {
      1: Color(0x06aaaa00),
      2: Color(0x16f4dd00),
      3: Color(0x47ffee00),
      4: Color(0x6bffe301),
      5: Color(0x8fffd500),
      6: Color(0x97ebbc00),
      7: Color(0x98d2a100),
      8: Color(0xc6c99700),
      9: Color(0xd6ffe100),
      10: Color(0xffffdc00),
      11: Color(0xff9e6c00),
      12: Color(0xe02e2000),
    }),
  ),
  Color(0xccfefbe4),
  Color(0xffffe629),
  Color(0xffffe629),
  Color(0xff21201c),
);

const _yellowDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffffe629, {
      1: Color(0xff14120b),
      2: Color(0xff1b180f),
      3: Color(0xff2d2305),
      4: Color(0xff362b00),
      5: Color(0xff433500),
      6: Color(0xff524202),
      7: Color(0xff665417),
      8: Color(0xff836a21),
      9: Color(0xffffe629),
      10: Color(0xffffff57),
      11: Color(0xfff5e147),
      12: Color(0xfff6eeb4),
    }),
    ColorSwatch(0xffffe629, {
      1: Color(0x04d15100),
      2: Color(0x0bf9b400),
      3: Color(0x1effaa00),
      4: Color(0x28fdb700),
      5: Color(0x36febb00),
      6: Color(0x46fec400),
      7: Color(0x5cfdcb22),
      8: Color(0x7bfdca32),
      9: Color(0xffffe629),
      10: Color(0xffffff57),
      11: Color(0xf5fee949),
      12: Color(0xf6fef6ba),
    }),
  ),
  Color(0x80231f13),
  Color(0xffffe629),
  Color(0xffd2b929),
  Color(0xff21201c),
);

// lime color scale
const _limeLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffbdee63, {
      1: Color(0xfffcfdfa),
      2: Color(0xfff8faf3),
      3: Color(0xffeef6d6),
      4: Color(0xffe2f0bd),
      5: Color(0xffd3e7a6),
      6: Color(0xffc2da91),
      7: Color(0xffabc978),
      8: Color(0xff8db654),
      9: Color(0xffbdee63),
      10: Color(0xffb0e64c),
      11: Color(0xff5c7c2f),
      12: Color(0xff37401c),
    }),
    ColorSwatch(0x9c93e400, {
      1: Color(0x05669900),
      2: Color(0x0c6b9500),
      3: Color(0x2996c800),
      4: Color(0x428fc600),
      5: Color(0x5981bb00),
      6: Color(0x6e72aa00),
      7: Color(0x87619900),
      8: Color(0xab559200),
      9: Color(0x9c93e400),
      10: Color(0xb38fdc00),
      11: Color(0xd0375f00),
      12: Color(0xe31e2900),
    }),
  ),
  Color(0xccf6f9f0),
  Color(0xffbdee63),
  Color(0xffbdee63),
  Color(0xff1d211c),
);

const _limeDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xffbdee63, {
      1: Color(0xff11130c),
      2: Color(0xff151a10),
      3: Color(0xff1f2917),
      4: Color(0xff29371d),
      5: Color(0xff334423),
      6: Color(0xff3d522a),
      7: Color(0xff496231),
      8: Color(0xff577538),
      9: Color(0xffbdee63),
      10: Color(0xffd4ff70),
      11: Color(0xffbde56c),
      12: Color(0xffe3f7ba),
    }),
    ColorSwatch(0xedcaff69, {
      1: Color(0x0311bb00),
      2: Color(0x0a78f700),
      3: Color(0x1a9bfd4c),
      4: Color(0x29a7fe5c),
      5: Color(0x37affe65),
      6: Color(0x46b2fe6d),
      7: Color(0x57b6ff6f),
      8: Color(0x6cb6fd6d),
      9: Color(0xedcaff69),
      10: Color(0xffd4ff70),
      11: Color(0xe4d1fe77),
      12: Color(0xf7e9febf),
    }),
  ),
  Color(0x801b2115),
  Color(0xffbdee63),
  Color(0xff98c254),
  Color(0xff1d211c),
);

// mint color scale
const _mintLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff86ead4, {
      1: Color(0xfff9fefd),
      2: Color(0xfff2fbf9),
      3: Color(0xffddf9f2),
      4: Color(0xffc8f4e9),
      5: Color(0xffb3ecde),
      6: Color(0xff9ce0d0),
      7: Color(0xff7ecfbd),
      8: Color(0xff4cbba5),
      9: Color(0xff86ead4),
      10: Color(0xff7de0cb),
      11: Color(0xff027864),
      12: Color(0xff16433c),
    }),
    ColorSwatch(0x7900d3a5, {
      1: Color(0x0600d5aa),
      2: Color(0x0d00b18a),
      3: Color(0x2200d29e),
      4: Color(0x3700cc99),
      5: Color(0x4c00c091),
      6: Color(0x6300b086),
      7: Color(0x8100a17d),
      8: Color(0xb3009e7f),
      9: Color(0x7900d3a5),
      10: Color(0x8200c399),
      11: Color(0xfd007763),
      12: Color(0xe900312a),
    }),
  ),
  Color(0xcceffaf8),
  Color(0xff86ead4),
  Color(0xff86ead4),
  Color(0xff1a211e),
);

const _mintDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff86ead4, {
      1: Color(0xff0e1515),
      2: Color(0xff0f1b1b),
      3: Color(0xff092c2b),
      4: Color(0xff003a38),
      5: Color(0xff004744),
      6: Color(0xff105650),
      7: Color(0xff1e685f),
      8: Color(0xff277f70),
      9: Color(0xff86ead4),
      10: Color(0xffa8f5e5),
      11: Color(0xff58d5ba),
      12: Color(0xffc4f5e1),
    }),
    ColorSwatch(0xe992ffe7, {
      1: Color(0x0500dede),
      2: Color(0x0b00f9f9),
      3: Color(0x1d00fff6),
      4: Color(0x2c00fff4),
      5: Color(0x3a00fff2),
      6: Color(0x4a0effeb),
      7: Color(0x5e34fde5),
      8: Color(0x7641ffdf),
      9: Color(0xe992ffe7),
      10: Color(0xf5aefeed),
      11: Color(0xd267ffde),
      12: Color(0xf5cbfee9),
    }),
  ),
  Color(0x80152727),
  Color(0xff86ead4),
  Color(0xff65c3b0),
  Color(0xff1a211e),
);

// sky color scale
const _skyLight = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff7ce2fe, {
      1: Color(0xfff9feff),
      2: Color(0xfff1fafd),
      3: Color(0xffe1f6fd),
      4: Color(0xffd1f0fa),
      5: Color(0xffbee7f5),
      6: Color(0xffa9daed),
      7: Color(0xff8dcae3),
      8: Color(0xff60b3d7),
      9: Color(0xff7ce2fe),
      10: Color(0xff74daf8),
      11: Color(0xff00749e),
      12: Color(0xff1d3e56),
    }),
    ColorSwatch(0x8300c7fe, {
      1: Color(0x0600d5ff),
      2: Color(0x0e00a4db),
      3: Color(0x1e00b3ee),
      4: Color(0x2e00ace4),
      5: Color(0x4100a1d8),
      6: Color(0x560092ca),
      7: Color(0x720089c1),
      8: Color(0x9f0085bf),
      9: Color(0x8300c7fe),
      10: Color(0x8b00bcf3),
      11: Color(0xff00749e),
      12: Color(0xe2002540),
    }),
  ),
  Color(0xcceef9fd),
  Color(0xff7ce2fe),
  Color(0xff7ce2fe),
  Color(0xff1c2024),
);

const _skyDark = RadixColor(
  RadixColorScale(
    ColorSwatch(0xff7ce2fe, {
      1: Color(0xff0d141f),
      2: Color(0xff111a27),
      3: Color(0xff112840),
      4: Color(0xff113555),
      5: Color(0xff154467),
      6: Color(0xff1b537b),
      7: Color(0xff1f6692),
      8: Color(0xff197cae),
      9: Color(0xff7ce2fe),
      10: Color(0xffa8eeff),
      11: Color(0xff75c7f0),
      12: Color(0xffc2f3ff),
    }),
    ColorSwatch(0xfe7ce3ff, {
      1: Color(0x0f0044ff),
      2: Color(0x181171fb),
      3: Color(0x331184fc),
      4: Color(0x49128fff),
      5: Color(0x5d1c9dfd),
      6: Color(0x7228a5ff),
      7: Color(0x8b2badfe),
      8: Color(0xa91db2fe),
      9: Color(0xfe7ce3ff),
      10: Color(0xffa8eeff),
      11: Color(0xef7cd3ff),
      12: Color(0xffc2f3ff),
    }),
  ),
  Color(0x8013233b),
  Color(0xff7ce2fe),
  Color(0xff5bbde2),
  Color(0xff1c2024),
);

// blackA neutral
const _blackAlphaAlpha = ColorSwatch(0xb3000000, {
  1: Color(0x0d000000),
  2: Color(0x1a000000),
  3: Color(0x26000000),
  4: Color(0x33000000),
  5: Color(0x4d000000),
  6: Color(0x66000000),
  7: Color(0x80000000),
  8: Color(0x99000000),
  9: Color(0xb3000000),
  10: Color(0xcc000000),
  11: Color(0xe6000000),
  12: Color(0xf2000000),
});

// whiteA neutral
const _whiteAlphaAlpha = ColorSwatch(0xb3ffffff, {
  1: Color(0x0dffffff),
  2: Color(0x1affffff),
  3: Color(0x26ffffff),
  4: Color(0x33ffffff),
  5: Color(0x4dffffff),
  6: Color(0x66ffffff),
  7: Color(0x80ffffff),
  8: Color(0x99ffffff),
  9: Color(0xb3ffffff),
  10: Color(0xccffffff),
  11: Color(0xe6ffffff),
  12: Color(0xf2ffffff),
});

// Color theme instances
const gray = RadixColorTheme(_grayLight, _grayDark);
const mauve = RadixColorTheme(_mauveLight, _mauveDark);
const slate = RadixColorTheme(_slateLight, _slateDark);
const sage = RadixColorTheme(_sageLight, _sageDark);
const olive = RadixColorTheme(_oliveLight, _oliveDark);
const sand = RadixColorTheme(_sandLight, _sandDark);
const tomato = RadixColorTheme(_tomatoLight, _tomatoDark);
const red = RadixColorTheme(_redLight, _redDark);
const ruby = RadixColorTheme(_rubyLight, _rubyDark);
const crimson = RadixColorTheme(_crimsonLight, _crimsonDark);
const pink = RadixColorTheme(_pinkLight, _pinkDark);
const plum = RadixColorTheme(_plumLight, _plumDark);
const purple = RadixColorTheme(_purpleLight, _purpleDark);
const violet = RadixColorTheme(_violetLight, _violetDark);
const iris = RadixColorTheme(_irisLight, _irisDark);
const indigo = RadixColorTheme(_indigoLight, _indigoDark);
const blue = RadixColorTheme(_blueLight, _blueDark);
const cyan = RadixColorTheme(_cyanLight, _cyanDark);
const teal = RadixColorTheme(_tealLight, _tealDark);
const jade = RadixColorTheme(_jadeLight, _jadeDark);
const green = RadixColorTheme(_greenLight, _greenDark);
const grass = RadixColorTheme(_grassLight, _grassDark);
const bronze = RadixColorTheme(_bronzeLight, _bronzeDark);
const gold = RadixColorTheme(_goldLight, _goldDark);
const brown = RadixColorTheme(_brownLight, _brownDark);
const orange = RadixColorTheme(_orangeLight, _orangeDark);
const amber = RadixColorTheme(_amberLight, _amberDark);
const yellow = RadixColorTheme(_yellowLight, _yellowDark);
const lime = RadixColorTheme(_limeLight, _limeDark);
const mint = RadixColorTheme(_mintLight, _mintDark);
const sky = RadixColorTheme(_skyLight, _skyDark);

// Neutral instances
const blackAlpha = _blackAlphaAlpha;
const whiteAlpha = _whiteAlphaAlpha;
