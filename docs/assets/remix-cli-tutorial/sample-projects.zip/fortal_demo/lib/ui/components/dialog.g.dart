// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dialog.dart';

// **************************************************************************
// MixWidgetGenerator
// **************************************************************************

/// Acme-themed preset for [RemixDialog].
///
/// The generated [AcmeDialog] defaults to [AcmeDialogSize.size3],
/// [AcmeDialogAlign.center], fills up to 600 logical pixels, preserves safe
/// viewport insets, and is modal.
class AcmeDialog extends StatelessWidget {
  const AcmeDialog({
    super.key,
    this.size = AcmeDialogSize.size3,
    this.align = AcmeDialogAlign.center,
    this.style = const DialogStyler.create(),
    this.child,
    this.title,
    this.description,
    this.actions,
    this.scrollable = false,
    this.modal = true,
    this.semanticLabel,
  });

  final AcmeDialogSize size;

  final AcmeDialogAlign align;

  final DialogStyler style;

  final Widget? child;

  final String? title;

  final String? description;

  final List<Widget>? actions;

  final bool scrollable;

  final bool modal;

  final String? semanticLabel;

  @override
  Widget build(BuildContext context) {
    return RemixDialog(
      key: this.key,
      style: acmeDialogStyle(
        size: this.size,
        align: this.align,
        style: this.style,
      ),
      child: this.child,
      title: this.title,
      description: this.description,
      actions: this.actions,
      scrollable: this.scrollable,
      modal: this.modal,
      semanticLabel: this.semanticLabel,
    );
  }
}
