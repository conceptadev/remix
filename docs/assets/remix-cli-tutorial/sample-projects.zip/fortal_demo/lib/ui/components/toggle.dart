import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'toggle.g.dart';

/// Acme toggle size presets.
enum AcmeToggleSize { size1, size2, size3 }

/// Acme toggle color and border variants.
enum AcmeToggleVariant { ghost, outline }

/// Acme-themed preset for [RemixToggle].
@MixWidget(target: RemixToggle.new)
ToggleStyler acmeToggleStyle({
  AcmeToggleVariant variant = .ghost,
  AcmeToggleSize size = .size2,
  bool highContrast = false,
  ToggleStyler style = const ToggleStyler.create(),
}) {
  return (switch (variant) {
    .ghost => _acmeToggleGhostStyler(size, highContrast: highContrast),
    .outline => _acmeToggleOutlineStyler(size, highContrast: highContrast),
  }).merge(style);
}

ToggleStyler _acmeToggleBaseStyler(AcmeToggleSize size) {
  return ToggleStyler()
      .container(.mainAxisSize(.min))
      .labelColor(AcmeTokens.gray12())
      .iconColor(AcmeTokens.gray12())
      .labelFontWeight(AcmeTokens.fontWeightMedium())
      .merge(_acmeToggleSizeStyler(size));
}

ToggleStyler _acmeToggleFocusStyler() => ToggleStyler().acmeFocusRing();

ToggleStyler _acmeToggleDisabledStyler({bool outlined = false}) {
  final style = ToggleStyler()
      .color(AcmeTokens.grayA3())
      .labelColor(AcmeTokens.gray8())
      .iconColor(AcmeTokens.gray8());
  return outlined
      ? style.border(
          .color(AcmeTokens.grayA6())
              .width(AcmeTokens.borderWidth1())
              .strokeAlign(BorderSide.strokeAlignInside),
        )
      : style;
}

ToggleStyler _acmeToggleGhostStyler(
  AcmeToggleSize size, {
  required bool highContrast,
}) {
  final selectedContent = highContrast
      ? AcmeTokens.accent12()
      : AcmeTokens.accent11();
  return _acmeToggleBaseStyler(size)
      .color(const Color(0x00000000))
      .onHovered(ToggleStyler().color(AcmeTokens.grayA3()))
      .onPressed(ToggleStyler().color(AcmeTokens.grayA4()))
      .onSelected(
        ToggleStyler()
            .color(AcmeTokens.accent3())
            .labelColor(selectedContent)
            .iconColor(selectedContent)
            .onHovered(ToggleStyler().color(AcmeTokens.accent4()))
            .onPressed(ToggleStyler().color(AcmeTokens.accent5())),
      )
      .onFocusVisible(_acmeToggleFocusStyler())
      .onDisabled(_acmeToggleDisabledStyler());
}

ToggleStyler _acmeToggleOutlineStyler(
  AcmeToggleSize size, {
  required bool highContrast,
}) {
  final selectedContent = highContrast
      ? AcmeTokens.accent12()
      : AcmeTokens.accent11();
  return _acmeToggleBaseStyler(size)
      .color(const Color(0x00000000))
      .border(
        .color(AcmeTokens.gray7())
            .width(AcmeTokens.borderWidth1())
            .strokeAlign(BorderSide.strokeAlignInside),
      )
      .onHovered(ToggleStyler().color(AcmeTokens.grayA3()))
      .onPressed(ToggleStyler().color(AcmeTokens.grayA4()))
      .onSelected(
        ToggleStyler()
            .color(AcmeTokens.accentA3())
            .labelColor(selectedContent)
            .iconColor(selectedContent)
            .border(.color(AcmeTokens.accentA5()))
            .onHovered(ToggleStyler().color(AcmeTokens.accentA4()))
            .onPressed(ToggleStyler().color(AcmeTokens.accentA5())),
      )
      .onFocusVisible(_acmeToggleFocusStyler())
      .onDisabled(_acmeToggleDisabledStyler(outlined: true));
}

ToggleStyler _acmeToggleSizeStyler(AcmeToggleSize size) {
  return switch (size) {
    .size1 => ToggleStyler(
      container: FlexBoxStyler()
          .padding(.horizontal(AcmeTokens.space2()))
          .padding(.vertical(AcmeTokens.space1()))
          .borderRadius(.all(AcmeTokens.radius2()))
          .spacing(AcmeTokens.toggleGap1()),
      label: .style(AcmeTokens.text1.mix()),
      icon: .size(AcmeTokens.space3()),
    ),
    .size2 => ToggleStyler(
      container: FlexBoxStyler()
          .padding(.horizontal(AcmeTokens.space3()))
          .padding(.vertical(AcmeTokens.space2()))
          .borderRadius(.all(AcmeTokens.radius2()))
          .spacing(AcmeTokens.space1()),
      label: .style(AcmeTokens.text2.mix()),
      icon: .size(AcmeTokens.space4()),
    ),
    .size3 => ToggleStyler(
      container: FlexBoxStyler()
          .padding(.horizontal(AcmeTokens.space4()))
          .padding(.vertical(AcmeTokens.space2()))
          .borderRadius(.all(AcmeTokens.radius3()))
          .spacing(AcmeTokens.toggleGap3()),
      label: .style(AcmeTokens.text3.mix()),
      icon: .size(AcmeTokens.spinnerSize3()),
    ),
  };
}
