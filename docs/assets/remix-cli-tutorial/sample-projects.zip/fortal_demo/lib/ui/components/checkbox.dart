import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'checkbox.g.dart';

/// Radix Themes Checkbox size presets.
enum AcmeCheckboxSize { size1, size2, size3 }

/// Radix Themes Checkbox variants.
enum AcmeCheckboxVariant { classic, surface, soft }

/// Acme recipe for [RemixCheckbox].
@MixWidget(target: RemixCheckbox.new)
CheckboxStyler acmeCheckboxStyle({
  AcmeCheckboxVariant variant = .surface,
  AcmeCheckboxSize size = .size2,
  bool highContrast = false,
  CheckboxStyler style = const CheckboxStyler.create(),
}) {
  final metrics = _acmeCheckboxMetrics(size);
  final base =
      CheckboxStyler(
        container: .size(
          metrics.size,
          metrics.size,
        ).alignment(.center).borderRadius(.all(metrics.radius)),
        indicator: .size(metrics.indicatorSize),
        containerEffects: RemixBoxEffectsMix(
          behindContent: RemixBoxEffectLayerMix(),
          overContent: RemixBoxEffectLayerMix(),
        ),
      ).onFocusVisible(
        .containerEffects(
          RemixBoxEffectsMix(
            outline: BorderSideMix(
              color: AcmeTokens.focus8(),
              width: 2,
              strokeAlign: BorderSide.strokeAlignInside,
            ),
            outlineOffset: 2,
          ),
        ),
      );

  return (switch (variant) {
    .classic => _acmeCheckboxClassic(base, highContrast),
    .surface => _acmeCheckboxSurface(base, highContrast),
    .soft => _acmeCheckboxSoft(base, highContrast),
  }).merge(style);
}

/// Acme recipe for [RemixCheckboxGroupItem].
///
/// Combines the mapped checkbox recipe with Radix's size-linked item label
/// typography and `0.5em` label gap. The behavioral group remains layout
/// transparent, so callers continue to own root direction and spacing.
///
/// It exists because `RemixCheckboxGroup` is behavioral and carries no styler,
/// so unlike every other Remix item (menu, select, segmented control, toggle
/// group) there is no parent recipe to push item styling down. Without this,
/// callers hand-attach a styler to each item and a missed one in a loop renders
/// unstyled beside its styled siblings.
@MixWidget(target: RemixCheckboxGroupItem.new)
CheckboxStyler acmeCheckboxGroupItemStyle({
  AcmeCheckboxVariant variant = .surface,
  AcmeCheckboxSize size = .size2,
  bool highContrast = false,
  CheckboxStyler style = const CheckboxStyler.create(),
}) {
  final checkbox = acmeCheckboxStyle(
    variant: variant,
    size: size,
    highContrast: highContrast,
  );

  return (switch (size) {
    .size1 =>
      checkbox
          .label(.style(AcmeTokens.text1.mix()))
          .labelSpacing(AcmeTokens.checkboxGroupItemGap1()),
    .size2 =>
      checkbox
          .label(.style(AcmeTokens.text2.mix()))
          .labelSpacing(AcmeTokens.checkboxGroupItemGap2()),
    .size3 =>
      checkbox
          .label(.style(AcmeTokens.text3.mix()))
          .labelSpacing(AcmeTokens.checkboxGroupItemGap3()),
  }).merge(style);
}

({double size, double indicatorSize, Radius radius}) _acmeCheckboxMetrics(
  AcmeCheckboxSize size,
) => switch (size) {
  .size1 => (
    size: AcmeTokens.checkboxSize1(),
    indicatorSize: AcmeTokens.checkboxIndicatorSize1(),
    radius: AcmeTokens.checkboxRadius1(),
  ),
  .size2 => (
    size: AcmeTokens.space4(),
    indicatorSize: AcmeTokens.checkboxIndicatorSize2(),
    radius: AcmeTokens.radius1(),
  ),
  .size3 => (
    size: AcmeTokens.checkboxSize3(),
    indicatorSize: AcmeTokens.checkboxIndicatorSize3(),
    radius: AcmeTokens.checkboxRadius3(),
  ),
};

CheckboxStyler _acmeCheckboxSurface(CheckboxStyler base, bool highContrast) {
  final selected = CheckboxStyler()
      .color(
        highContrast ? AcmeTokens.accent12() : AcmeTokens.accentIndicator(),
      )
      .containerEffects(
        RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
      )
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          RemixBoxEffectLayerMix(shadows: const []),
        ),
      )
      .indicatorColor(
        highContrast ? AcmeTokens.accent1() : AcmeTokens.accentContrast(),
      );

  return base
      .color(AcmeTokens.colorSurface())
      .containerEffects(
        RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
      )
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          _acmeCheckboxInsetRing(AcmeTokens.grayA7()),
        ),
      )
      .onSelected(selected)
      .onIndeterminate(selected)
      .onDisabled(
        .color(AcmeTokens.grayA3())
            .containerEffects(
              RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
            )
            .containerEffects(
              RemixBoxEffectsMix.overContent(
                _acmeCheckboxInsetRing(AcmeTokens.grayA6()),
              ),
            )
            .indicatorColor(AcmeTokens.grayA8()),
      );
}

CheckboxStyler _acmeCheckboxClassic(CheckboxStyler base, bool highContrast) {
  final selected = CheckboxStyler()
      .color(
        highContrast ? AcmeTokens.accent12() : AcmeTokens.accentIndicator(),
      )
      .containerEffects(
        RemixBoxEffectsMix.behindContent(
          RemixBoxEffectLayerMix(
            gradients: [
              RemixLinearGradientMix(
                colors: [
                  AcmeTokens.whiteA3(),
                  const Color(0x00000000),
                  AcmeTokens.blackA1(),
                ],
              ),
            ],
            shadows: [
              RemixBoxShadowMix(
                kind: .inset,
                color: AcmeTokens.whiteA4(),
                offset: const Offset(0, 0.5),
                blurRadius: 0.5,
              ),
              RemixBoxShadowMix(
                kind: .inset,
                color: AcmeTokens.blackA4(),
                offset: const Offset(0, -0.5),
                blurRadius: 0.5,
              ),
            ],
          ),
        ),
      )
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          RemixBoxEffectLayerMix(shadows: const []),
        ),
      )
      .indicatorColor(
        highContrast ? AcmeTokens.accent1() : AcmeTokens.accentContrast(),
      );

  return base
      .color(AcmeTokens.colorSurface())
      .containerEffects(
        RemixBoxEffectsMix.behindContent(
          RemixBoxEffectLayerMix(shadowToken: AcmeTokens.shadow1Layers),
        ),
      )
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          _acmeCheckboxInsetRing(AcmeTokens.grayA3()),
        ),
      )
      .onSelected(selected)
      .onIndeterminate(selected)
      .onDisabled(
        .color(AcmeTokens.grayA3())
            .containerEffects(
              RemixBoxEffectsMix.behindContent(
                RemixBoxEffectLayerMix(
                  gradients: const [],
                  shadowToken: AcmeTokens.shadow1Layers,
                ),
              ),
            )
            .containerEffects(
              RemixBoxEffectsMix.overContent(
                RemixBoxEffectLayerMix(shadows: const []),
              ),
            )
            .indicatorColor(AcmeTokens.grayA8()),
      );
}

CheckboxStyler _acmeCheckboxSoft(CheckboxStyler base, bool highContrast) {
  final selected = CheckboxStyler().indicatorColor(
    highContrast ? AcmeTokens.accent12() : AcmeTokens.accentA11(),
  );

  return base
      .color(AcmeTokens.accentA5())
      .containerEffects(
        RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
      )
      .onSelected(selected)
      .onIndeterminate(selected)
      .onDisabled(
        .color(AcmeTokens.grayA3())
            .containerEffects(
              RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
            )
            .indicatorColor(AcmeTokens.grayA8()),
      );
}

RemixBoxEffectLayerMix _acmeCheckboxInsetRing(Color color) =>
    RemixBoxEffectLayerMix(
      shadows: [RemixBoxShadowMix(kind: .inset, color: color, spreadRadius: 1)],
    );
