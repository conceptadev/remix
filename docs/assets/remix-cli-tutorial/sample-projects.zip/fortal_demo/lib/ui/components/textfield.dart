// `DragStartBehavior` and `MaxLengthEnforcement` appear in the generated
// AcmeTextField/AcmeTextArea constructors, so they must be visible from
// this library even though nothing here references them directly.
import 'package:flutter/gestures.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'textfield.g.dart';

/// Acme text field size presets.
enum AcmeTextFieldSize {
  /// Compact text field.
  size1,

  /// Default text field.
  size2,

  /// Large text field.
  size3,
}

/// Acme text field color variants.
enum AcmeTextFieldVariant {
  /// Raised treatment with Radix's level-one shadow.
  classic,

  /// Surface treatment with neutral border and text colors.
  surface,

  /// Soft accent treatment.
  soft,
}

Color _resolveNeutralTextInputPlaceholder(BuildContext context) {
  final color = AcmeTokens.grayA10.resolve(context);
  return color.withValues(alpha: color.a * 0.5);
}

const _neutralTextInputPlaceholder = ContextToken<Color>(
  _resolveNeutralTextInputPlaceholder,
);

/// Acme-themed preset for [RemixTextField].
@MixWidget(target: RemixTextField.new)
TextFieldStyler acmeTextFieldStyle({
  AcmeTextFieldVariant variant = .surface,
  AcmeTextFieldSize size = .size2,
  TextFieldStyler style = const TextFieldStyler.create(),
}) {
  final metrics = _acmeTextFieldMetrics(size, bordered: variant != .soft);
  final base = _acmeTextInputBaseStyle(
    container: BoxStyler()
        .height(metrics.height)
        .padding(.horizontal(metrics.paddingX))
        .borderRadius(.all(metrics.radius))
        .clipBehavior(.antiAlias),
    spacing: metrics.spacing,
    crossAxisAlignment: .center,
    text: metrics.text,
    focusColor: switch (variant) {
      .soft => AcmeTokens.accent8(),
      .classic || .surface => AcmeTokens.focus8(),
    },
  );

  final recipe = switch (variant) {
    .classic => _acmeApplyClassicTextInput(base),
    .surface => _acmeApplySurfaceTextInput(base),
    .soft => _acmeApplySoftTextInput(base, placeholderOpacity: 0.60),
  };

  return recipe
      .variant(ContextVariant.widgetState(.error), _acmeTextInputErrorStyle())
      .merge(style);
}

TextFieldStyler _acmeTextInputBaseStyle({
  required BoxStyler container,
  required double spacing,
  required CrossAxisAlignment crossAxisAlignment,
  required TextStyleToken text,
  required Color focusColor,
}) =>
    TextFieldStyler(
          container: container,
          spacing: spacing,
          crossAxisAlignment: crossAxisAlignment,
          text: .style(text.mix()),
          hintText: .style(text.mix()).textHeightBehavior(
            TextHeightBehaviorMix()
                .applyHeightToFirstAscent(false)
                .applyHeightToLastDescent(true),
          ),
          helperText: .style(AcmeTokens.text1.mix()),
          label: .style(AcmeTokens.text2.mix()),
          cursorWidth: 1.5,
          containerEffects: RemixBoxEffectsMix(
            behindContent: RemixBoxEffectLayerMix(),
            overContent: RemixBoxEffectLayerMix(),
          ),
        )
        .wrap(.iconTheme(color: AcmeTokens.gray11(), size: 16.0))
        // Radix keys text-input rings from :focus/:focus-within, so unlike
        // control focus rings this intentionally follows raw focus.
        .onFocused(.containerEffects(acmeFocusOutline(focusColor, offset: -1)));

TextFieldStyler _acmeApplyClassicTextInput(TextFieldStyler base) =>
    _acmeApplyNeutralTextInput(base)
        .color(AcmeTokens.colorSurface())
        .containerEffects(
          RemixBoxEffectsMix.behindContent(
            RemixBoxEffectLayerMix(shadowToken: AcmeTokens.shadow1Layers),
          ),
        )
        .onDisabled(
          _acmeNeutralTextInputDisabledStyle()
              .color(AcmeTokens.colorSurface())
              .containerEffects(
                RemixBoxEffectsMix.behindContent(
                  RemixBoxEffectLayerMix(
                    gradients: [
                      RemixLinearGradientMix(
                        colors: [AcmeTokens.grayA2(), AcmeTokens.grayA2()],
                      ),
                    ],
                    shadowToken: AcmeTokens.shadow1Layers,
                  ),
                ),
              ),
        );

TextFieldStyler _acmeApplySurfaceTextInput(TextFieldStyler base) =>
    _acmeApplyNeutralTextInput(base)
        .color(AcmeTokens.colorSurface())
        .containerEffects(
          RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
        )
        .containerEffects(
          RemixBoxEffectsMix.overContent(
            _acmeTextInputInsetRing(AcmeTokens.grayA7()),
          ),
        )
        .onDisabled(
          _acmeNeutralTextInputDisabledStyle()
              .color(AcmeTokens.colorSurface())
              .containerEffects(
                RemixBoxEffectsMix.behindContent(
                  RemixBoxEffectLayerMix(
                    gradients: [
                      RemixLinearGradientMix(
                        colors: [AcmeTokens.grayA2(), AcmeTokens.grayA2()],
                      ),
                    ],
                  ),
                ),
              )
              .containerEffects(
                RemixBoxEffectsMix.overContent(
                  _acmeTextInputInsetRing(AcmeTokens.grayA6()),
                ),
              ),
        );

TextFieldStyler _acmeApplySoftTextInput(
  TextFieldStyler base, {
  required double placeholderOpacity,
}) => base
    .merge(
      TextFieldStyler(
        text: .fontWeight(AcmeTokens.fontWeightRegular()),
        hintText: .fontWeight(AcmeTokens.fontWeightRegular()),
        cursorColor: AcmeTokens.accent12(),
        helperText: .color(
          AcmeTokens.gray11(),
        ).fontWeight(AcmeTokens.fontWeightRegular()),
        label: .color(
          AcmeTokens.gray12(),
        ).fontWeight(AcmeTokens.fontWeightMedium()),
      ),
    )
    .textColor(AcmeTokens.accent12())
    .text(.selectionColor(AcmeTokens.accentA5()))
    .onEnabled(
      .hintText(
        .color(AcmeTokens.accent12().withValues(alpha: placeholderOpacity)),
      ),
    )
    .wrap(.iconTheme(color: AcmeTokens.accent10()))
    .color(AcmeTokens.accentA3())
    .containerEffects(
      RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
    )
    .onDisabled(
      _acmeSoftTextInputDisabledStyle()
          .color(AcmeTokens.grayA3())
          .containerEffects(
            RemixBoxEffectsMix.behindContent(RemixBoxEffectLayerMix()),
          ),
    );

TextFieldStyler _acmeApplyNeutralTextInput(TextFieldStyler base) => base.merge(
  TextFieldStyler(
    text: .color(AcmeTokens.gray12()).selectionColor(AcmeTokens.focusA5()),
    hintText: .color(_neutralTextInputPlaceholder()),
    cursorColor: AcmeTokens.gray12(),
    helperText: .color(AcmeTokens.gray11()),
    label: .color(
      AcmeTokens.gray12(),
    ).fontWeight(AcmeTokens.fontWeightMedium()),
  ),
);

// Keep the disabled-color branch on raw focus for the same :focus-within
// contract as the enabled text input.
TextFieldStyler _acmeTextInputDisabledBaseStyle() =>
    TextFieldStyler(
      text: .color(AcmeTokens.grayA11()).selectionColor(AcmeTokens.grayA5()),
      cursorColor: AcmeTokens.grayA11(),
    ).onFocused(
      .containerEffects(acmeFocusOutline(AcmeTokens.gray8(), offset: -1)),
    );

TextFieldStyler _acmeNeutralTextInputDisabledStyle() =>
    _acmeTextInputDisabledBaseStyle().hintText(
      .color(_neutralTextInputPlaceholder()),
    );

TextFieldStyler _acmeSoftTextInputDisabledStyle() =>
    _acmeTextInputDisabledBaseStyle().hintText(
      .color(AcmeTokens.accent12().withValues(alpha: 0.5)),
    );

TextFieldStyler _acmeTextInputErrorStyle() => TextFieldStyler(
  helperText: .color(AcmeTokens.error11()),
  label: .color(AcmeTokens.error11()),
  cursorColor: AcmeTokens.error9(),
  containerEffects: RemixBoxEffectsMix(
    overContent: RemixBoxEffectLayerMix(
      shadows: [
        RemixBoxShadowMix(
          kind: .inset,
          color: AcmeTokens.errorA7(),
          spreadRadius: 1,
        ),
      ],
    ),
    outline: BorderSideMix(
      color: AcmeTokens.error8(),
      width: 2,
      strokeAlign: BorderSide.strokeAlignInside,
    ),
    outlineOffset: -1,
  ),
);

({
  double height,
  double paddingX,
  double spacing,
  Radius radius,
  TextStyleToken text,
})
_acmeTextFieldMetrics(
  AcmeTextFieldSize size, {
  required bool bordered,
}) => switch (size) {
  .size1 => (
    height: AcmeTokens.space5(),
    paddingX: bordered
        ? AcmeTokens.textFieldPadding1()
        : AcmeTokens.selectSpace1Half(),
    spacing: AcmeTokens.space2(),
    radius: AcmeTokens.radius2OrFull(),
    text: AcmeTokens.text1,
  ),
  .size2 => (
    height: AcmeTokens.space6(),
    paddingX: bordered ? AcmeTokens.textFieldPadding2() : AcmeTokens.space2(),
    spacing: AcmeTokens.space2(),
    radius: AcmeTokens.radius2OrFull(),
    text: AcmeTokens.text2,
  ),
  .size3 => (
    height: AcmeTokens.space7(),
    paddingX: bordered ? AcmeTokens.textFieldPadding3() : AcmeTokens.space3(),
    spacing: AcmeTokens.space3(),
    radius: AcmeTokens.radius3OrFull(),
    text: AcmeTokens.text3,
  ),
};

RemixBoxEffectLayerMix _acmeTextInputInsetRing(Color color) =>
    RemixBoxEffectLayerMix(
      shadows: [RemixBoxShadowMix(kind: .inset, color: color, spreadRadius: 1)],
    );

/// Radix Themes TextArea size presets.
enum AcmeTextAreaSize { size1, size2, size3 }

/// Radix Themes TextArea variants.
enum AcmeTextAreaVariant { classic, surface, soft }

/// Acme recipe for [RemixTextArea].
///
/// Scrolling follows the host platform; this recipe does not reproduce Radix's
/// themed browser scrollbar or resize handle.
@MixWidget(target: RemixTextArea.new)
TextFieldStyler acmeTextAreaStyle({
  AcmeTextAreaVariant variant = .surface,
  AcmeTextAreaSize size = .size2,
  TextFieldStyler style = const TextFieldStyler.create(),
}) {
  final metrics = _acmeTextAreaMetrics(size);
  final base = _acmeTextInputBaseStyle(
    container: BoxStyler()
        .minHeight(metrics.minHeight)
        .padding(
          .symmetric(horizontal: metrics.paddingX, vertical: metrics.paddingY),
        )
        .borderRadius(.all(metrics.radius))
        .clipBehavior(.antiAlias),
    spacing: metrics.spacing,
    crossAxisAlignment: .start,
    text: metrics.text,
    focusColor: switch (variant) {
      .soft => AcmeTokens.accent8(),
      .classic || .surface => AcmeTokens.focus8(),
    },
  );

  final recipe = switch (variant) {
    .classic => _acmeApplyClassicTextInput(base),
    .surface => _acmeApplySurfaceTextInput(base),
    .soft => _acmeApplySoftTextInput(base, placeholderOpacity: 0.65),
  };

  return recipe
      .variant(ContextVariant.widgetState(.error), _acmeTextInputErrorStyle())
      .merge(style);
}

({
  double minHeight,
  double paddingX,
  double paddingY,
  double spacing,
  Radius radius,
  TextStyleToken text,
})
_acmeTextAreaMetrics(AcmeTextAreaSize size) => switch (size) {
  .size1 => (
    minHeight: AcmeTokens.space8(),
    paddingX: AcmeTokens.selectSpace1Half(),
    paddingY: AcmeTokens.space1(),
    spacing: AcmeTokens.space2(),
    radius: AcmeTokens.radius2(),
    text: AcmeTokens.text1,
  ),
  .size2 => (
    minHeight: AcmeTokens.space9(),
    paddingX: AcmeTokens.space2(),
    paddingY: AcmeTokens.selectSpace1Half(),
    spacing: AcmeTokens.space2(),
    radius: AcmeTokens.radius2(),
    text: AcmeTokens.text2,
  ),
  .size3 => (
    minHeight: AcmeTokens.textAreaMinHeight3(),
    paddingX: AcmeTokens.space3(),
    paddingY: AcmeTokens.space2(),
    spacing: AcmeTokens.space3(),
    radius: AcmeTokens.radius3(),
    text: AcmeTokens.text3,
  ),
};
