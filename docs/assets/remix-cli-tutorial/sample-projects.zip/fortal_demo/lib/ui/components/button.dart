import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import 'base_button.dart';
import '../theme/theme.dart';

part 'button.g.dart';

/// Radix Themes Button size presets.
enum AcmeButtonSize { size1, size2, size3, size4 }

/// Radix Themes Button variants.
enum AcmeButtonVariant { classic, solid, soft, surface, outline, ghost }

/// Acme-themed Button with the Radix size, variant, and override contract.
@MixWidget(target: RemixButton.new)
ButtonStyler acmeButtonStyle({
  AcmeButtonVariant variant = .solid,
  AcmeButtonSize size = .size2,
  bool highContrast = false,
  ButtonStyler style = const ButtonStyler.create(),
}) {
  final base = _acmeButtonBaseStyler(variant, _acmeBaseButtonSize(size));
  final stateStyles = acmeBaseButtonStateStyles(
    variant: _acmeBaseButtonVariant(variant),
    highContrast: highContrast,
  );

  return _applyAcmeButtonStateStyles(
    base,
    stateStyles,
    pressedPaddingTop: variant == .classic ? (size == .size1 ? 1 : 2) : null,
  ).merge(style);
}

ButtonStyler _acmeButtonBaseStyler(
  AcmeButtonVariant variant,
  AcmeBaseButtonSize size,
) {
  final metrics = acmeBaseButtonMetrics(size);
  var style = ButtonStyler(
    container: .direction(.horizontal).mainAxisSize(.min).spacing(metrics.gap),
    label: .style(metrics.text.mix()).fontWeight(
      variant == .ghost
          ? AcmeTokens.fontWeightRegular()
          : AcmeTokens.fontWeightMedium(),
    ),
    spinner: .size(metrics.spinnerSize)
        .opacity(0.65)
        .leafRadius(AcmeTokens.radius1())
        .duration(const Duration(milliseconds: 800)),
  ).borderRadius(.all(metrics.radius));

  if (variant == .ghost) {
    final ghost = acmeBaseButtonGhostMetrics(size);
    style = style
        .spacing(ghost.gap)
        .padding(
          .symmetric(horizontal: ghost.paddingX, vertical: ghost.paddingY),
        )
        .margin(.symmetric(horizontal: ghost.marginX, vertical: ghost.marginY));
  } else {
    style = style
        .minHeight(metrics.height)
        .padding(.horizontal(metrics.paddingX))
        .icon(.opacity(0.9));
  }
  return style;
}

AcmeBaseButtonVariant _acmeBaseButtonVariant(AcmeButtonVariant variant) =>
    switch (variant) {
      .classic => .classic,
      .solid => .solid,
      .soft => .soft,
      .surface => .surface,
      .outline => .outline,
      .ghost => .ghost,
    };

AcmeBaseButtonSize _acmeBaseButtonSize(AcmeButtonSize size) => switch (size) {
  .size1 => .size1,
  .size2 => .size2,
  .size3 => .size3,
  .size4 => .size4,
};

ButtonStyler _applyAcmeButtonStateStyles(
  ButtonStyler base,
  AcmeBaseButtonStateStyles stateStyles, {
  required double? pressedPaddingTop,
}) {
  var pressed = _applyAcmeButtonState(ButtonStyler(), stateStyles.pressed);
  if (pressedPaddingTop != null) {
    pressed = pressed.padding(.top(pressedPaddingTop));
  }

  return _applyAcmeButtonState(base, stateStyles.idle)
      .onHovered(_applyAcmeButtonState(ButtonStyler(), stateStyles.hovered))
      .onPressed(pressed)
      .onDisabled(_applyAcmeButtonState(ButtonStyler(), stateStyles.disabled))
      .onFocusVisible(
        _applyAcmeButtonState(ButtonStyler(), stateStyles.focusVisible),
      )
      .onDisabled(
        _applyAcmeButtonState(ButtonStyler(), stateStyles.disabledFocus),
      );
}

ButtonStyler _applyAcmeButtonState(
  ButtonStyler style,
  AcmeBaseButtonStateStyle state,
) {
  var result = style;
  final foreground = state.foreground;
  if (foreground != null) {
    result = result
        .label(.color(foreground))
        .icon(.color(foreground))
        .spinner(.color(foreground));
  }
  if (state.background != null) {
    result = result.color(state.background!);
  }
  if (state.effects != null) {
    result = result.containerEffects(state.effects!);
  }
  if (state.spinnerOpacity != null) {
    result = result.spinner(.opacity(state.spinnerOpacity!));
  }
  if (state.modifier != null) {
    result = result.wrap(state.modifier!);
  }
  return result;
}
