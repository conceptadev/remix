import 'dart:math' as math;

import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'dialog.g.dart';

/// Acme dialog size presets matching Radix Themes 3.3.0.
enum AcmeDialogSize { size1, size2, size3, size4 }

/// Acme dialog vertical alignment matching Radix Themes 3.3.0.
enum AcmeDialogAlign { start, center }

final _dialogViewportInsets = ContextToken<EdgeInsetsGeometry>((context) {
  final safeArea = MediaQuery.paddingOf(context);
  final viewportHeight = MediaQuery.sizeOf(context).height;
  final horizontal = AcmeTokens.space4.resolve(context);
  final vertical = AcmeTokens.space6.resolve(context);

  return EdgeInsets.fromLTRB(
    math.max(safeArea.left, horizontal),
    math.max(safeArea.top, vertical),
    math.max(safeArea.right, horizontal),
    math.max(safeArea.bottom, math.max(vertical, viewportHeight * 0.06)),
  );
});

/// Acme-themed preset for [RemixDialog].
///
/// The generated [AcmeDialog] defaults to [AcmeDialogSize.size3],
/// [AcmeDialogAlign.center], fills up to 600 logical pixels, preserves safe
/// viewport insets, and is modal.
@MixWidget(target: RemixDialog.new)
DialogStyler acmeDialogStyle({
  AcmeDialogSize size = AcmeDialogSize.size3,
  AcmeDialogAlign align = AcmeDialogAlign.center,
  DialogStyler style = const DialogStyler.create(),
}) {
  final radius = switch (size) {
    AcmeDialogSize.size1 || AcmeDialogSize.size2 => AcmeTokens.radius4(),
    AcmeDialogSize.size3 || AcmeDialogSize.size4 => AcmeTokens.radius5(),
  };
  final padding = switch (size) {
    AcmeDialogSize.size1 => AcmeTokens.space3(),
    AcmeDialogSize.size2 => AcmeTokens.space4(),
    AcmeDialogSize.size3 => AcmeTokens.space5(),
    AcmeDialogSize.size4 => AcmeTokens.space6(),
  };
  final alignment = switch (align) {
    AcmeDialogAlign.start => Alignment.topCenter,
    AcmeDialogAlign.center => Alignment.center,
  };

  return DialogStyler()
      .wrap(
        .modifier(
          PaddingModifierMix.create(padding: Prop.token(_dialogViewportInsets)),
        ).align(alignment: alignment).orderOfModifiers([
          PaddingModifier,
          AlignModifier,
        ]),
      )
      .title(
        .style(AcmeTokens.text5.mix())
            .fontWeight(AcmeTokens.fontWeightBold())
            .color(AcmeTokens.gray12())
            .wrap(
              .padding(EdgeInsetsMix.fromLTRB(0, 0, 0, AcmeTokens.space3())),
            ),
      )
      .description(
        TextStyler(style: AcmeTokens.text3.mix()).color(AcmeTokens.gray12()),
      )
      .actions(
        FlexBoxStyler()
            .mainAxisAlignment(.end)
            .spacing(AcmeTokens.space3())
            .margin(.top(AcmeTokens.space5())),
      )
      .width(600)
      .padding(.all(padding))
      .borderRadius(.all(radius))
      .color(AcmeTokens.colorPanel())
      .decoration(BoxDecorationMix.create(boxShadow: AcmeTokens.shadow6.mix()))
      .containerEffects(RemixBoxEffectsMix.backdropBlur(AcmeTokens.panelBlur()))
      .merge(style);
}
