import 'package:flutter/widgets.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

/// The nine-step Radix Themes text scale supplied by [AcmeTokens].
enum AcmeTextSize {
  size1,
  size2,
  size3,
  size4,
  size5,
  size6,
  size7,
  size8,
  size9,
}

/// Font weights supported by the Acme typography scale.
///
/// Closed rather than Flutter's [FontWeight], which is an open class accepting
/// any value from 1 to 1000; Radix ships exactly these four.
enum AcmeTextWeight { light, regular, medium, bold }

TextStyleToken acmeTextSizeToken(AcmeTextSize size) => switch (size) {
  .size1 => AcmeTokens.text1,
  .size2 => AcmeTokens.text2,
  .size3 => AcmeTokens.text3,
  .size4 => AcmeTokens.text4,
  .size5 => AcmeTokens.text5,
  .size6 => AcmeTokens.text6,
  .size7 => AcmeTokens.text7,
  .size8 => AcmeTokens.text8,
  .size9 => AcmeTokens.text9,
};

FontWeightToken acmeTextWeightToken(AcmeTextWeight weight) => switch (weight) {
  .light => AcmeTokens.fontWeightLight,
  .regular => AcmeTokens.fontWeightRegular,
  .medium => AcmeTokens.fontWeightMedium,
  .bold => AcmeTokens.fontWeightBold,
};

/// [truncate] deliberately wins over [softWrap], forcing one ellipsized line.
TextStyler acmeApplyTextFlow(
  TextStyler style, {
  TextAlign? align,
  required bool softWrap,
  required bool truncate,
}) {
  if (align != null) style = style.textAlign(align);
  if (truncate) {
    return style.maxLines(1).softWrap(false).overflow(TextOverflow.ellipsis);
  }

  return style.softWrap(softWrap);
}

TextStyler acmeAccentForeground(
  TextStyler style, {
  required bool highContrast,
}) =>
    style.color(highContrast ? AcmeTokens.accent12() : AcmeTokens.accentA11());

/// Code, Kbd, and Link derive em-relative geometry from the resolved font size,
/// so unlike the other recipes they cannot stay context-free.
TextStyle acmeResolveTextToken(BuildContext context, AcmeTextSize size) =>
    MixScope.tokenOf(acmeTextSizeToken(size), context);

Color acmeResolveColor(BuildContext context, ColorToken token) =>
    MixScope.tokenOf(token, context);

/// Derived from the resolved `radius1` rather than duplicating the Acme
/// radius enum table, so theme radius and scaling changes flow through.
double acmeRadiusFactor(BuildContext context) {
  final scaling = AcmeTheme.of(context).scaling.factor;
  final radius = MixScope.tokenOf(AcmeTokens.radius1, context);

  return radius.x / (3 * scaling);
}
