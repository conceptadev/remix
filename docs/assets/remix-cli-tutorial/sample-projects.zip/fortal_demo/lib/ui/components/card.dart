import 'package:flutter/widgets.dart';
import 'package:mix_annotations/mix_annotations.dart';
import 'package:remix/remix.dart';

import '../theme/theme.dart';

part 'card.g.dart';

/// Radix Themes Card size presets.
enum AcmeCardSize { size1, size2, size3, size4, size5 }

/// Radix Themes Card variants.
enum AcmeCardVariant { surface, classic, ghost }

/// Acme-themed Card with the Radix size and variant contract.
@MixWidget(target: RemixCard.new)
CardStyler acmeCardStyle({
  AcmeCardVariant variant = .surface,
  AcmeCardSize size = .size1,
  CardStyler style = const CardStyler.create(),
}) {
  final metrics = _acmeCardMetrics(size);
  final base = CardStyler()
      .padding(.all(metrics.padding))
      .borderRadius(.all(metrics.radius))
      .clipBehavior(Clip.antiAlias)
      .onFocusVisible(
        .containerEffects(
          RemixBoxEffectsMix(
            outline: BorderSideMix(
              color: AcmeTokens.focus8(),
              width: 2,
              strokeAlign: BorderSide.strokeAlignInside,
            ),
            outlineOffset: -1,
          ),
        ),
      );

  return (switch (variant) {
    .surface => _acmeCardSurface(base),
    .classic => _acmeCardClassic(base),
    .ghost => _acmeCardGhost(base, metrics.ghostMargin),
  }).merge(style);
}

({double padding, double ghostMargin, Radius radius}) _acmeCardMetrics(
  AcmeCardSize size,
) => switch (size) {
  .size1 => (
    padding: AcmeTokens.space3(),
    ghostMargin: AcmeTokens.cardGhostMargin1(),
    radius: AcmeTokens.radius4(),
  ),
  .size2 => (
    padding: AcmeTokens.space4(),
    ghostMargin: AcmeTokens.cardGhostMargin2(),
    radius: AcmeTokens.radius4(),
  ),
  .size3 => (
    padding: AcmeTokens.space5(),
    ghostMargin: AcmeTokens.cardGhostMargin3(),
    radius: AcmeTokens.radius5(),
  ),
  .size4 => (
    padding: AcmeTokens.space6(),
    ghostMargin: AcmeTokens.cardGhostMargin4(),
    radius: AcmeTokens.radius5(),
  ),
  .size5 => (
    padding: AcmeTokens.space8(),
    ghostMargin: AcmeTokens.cardGhostMargin5(),
    radius: AcmeTokens.radius6(),
  ),
};

CardStyler _acmeCardSurface(CardStyler base) {
  base = base.containerEffects(
    RemixBoxEffectsMix.backdropBlur(AcmeTokens.panelBlur()),
  );
  final open = CardStyler()
      .containerEffects(RemixBoxEffectsMix.behindContent(_acmeCardPanel()))
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          _acmeCardSurfaceStroke(AcmeTokens.grayStroke7()),
        ),
      );
  final activeFocus = CardStyler()
      .containerEffects(
        RemixBoxEffectsMix.behindContent(_acmeCardActiveFocus()),
      )
      .onSelected(open);
  final pressed = CardStyler()
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          _acmeCardSurfaceStroke(AcmeTokens.grayStroke6()),
        ),
      )
      .onFocusVisible(activeFocus)
      .onSelected(open);

  return base
      .containerEffects(RemixBoxEffectsMix.behindContent(_acmeCardPanel()))
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          _acmeCardSurfaceStroke(AcmeTokens.grayStroke5()),
        ),
      )
      .onHovered(open)
      .onPressed(pressed)
      .onSelected(open.onPressed(open));
}

CardStyler _acmeCardClassic(CardStyler base) {
  base = base.containerEffects(
    RemixBoxEffectsMix.backdropBlur(AcmeTokens.panelBlur()),
  );
  final open = CardStyler()
      .animate(AnimationConfig.ease(const Duration(milliseconds: 40)))
      .containerEffects(
        RemixBoxEffectsMix.behindContent(
          _acmeCardPanel(shadowToken: AcmeTokens.cardClassicHoverOuterShadows),
        ),
      )
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          RemixBoxEffectLayerMix(
            shadowToken: AcmeTokens.cardClassicHoverInnerShadows,
          ),
        ),
      );
  final pressed = CardStyler()
      .animate(AnimationConfig.ease(const Duration(milliseconds: 40)))
      .containerEffects(
        RemixBoxEffectsMix.behindContent(
          RemixBoxEffectLayerMix(
            shadowToken: AcmeTokens.cardClassicActiveOuterShadows,
          ),
        ),
      )
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          RemixBoxEffectLayerMix(
            shadowToken: AcmeTokens.cardClassicActiveInnerShadows,
          ),
        ),
      )
      .onFocusVisible(
        .containerEffects(
          RemixBoxEffectsMix.behindContent(_acmeCardActiveFocus()),
        ).onSelected(open),
      )
      .onSelected(open);

  return base
      .animate(AnimationConfig.ease(const Duration(milliseconds: 120)))
      .containerEffects(
        RemixBoxEffectsMix.behindContent(
          _acmeCardPanel(shadowToken: AcmeTokens.cardClassicOuterShadows),
        ),
      )
      .containerEffects(
        RemixBoxEffectsMix.overContent(
          RemixBoxEffectLayerMix(
            shadowToken: AcmeTokens.cardClassicInnerShadows,
          ),
        ),
      )
      .onHovered(open)
      .onPressed(pressed)
      .onSelected(open.onPressed(open));
}

CardStyler _acmeCardGhost(CardStyler base, double ghostMargin) {
  final focused = CardStyler().color(AcmeTokens.accentA2());
  final open = CardStyler().color(AcmeTokens.grayA3()).onFocusVisible(focused);
  final pressed = CardStyler()
      .color(AcmeTokens.grayA4())
      .onFocusVisible(focused)
      .onSelected(open);

  return base
      .margin(.all(ghostMargin))
      .color(const Color(0x00000000))
      .onHovered(open)
      .onPressed(pressed)
      .onSelected(open.onPressed(open));
}

RemixBoxEffectLayerMix _acmeCardPanel({RemixBoxShadowListToken? shadowToken}) =>
    RemixBoxEffectLayerMix(
      gradients: [
        RemixLinearGradientMix(
          colors: [AcmeTokens.colorPanel(), AcmeTokens.colorPanel()],
        ),
      ],
      gradientInsets: const [1],
      shadowToken: shadowToken,
    );

RemixBoxEffectLayerMix _acmeCardActiveFocus() => RemixBoxEffectLayerMix(
  gradients: [
    RemixLinearGradientMix(
      colors: [AcmeTokens.accentA2(), AcmeTokens.accentA2()],
    ),
    RemixLinearGradientMix(
      colors: [AcmeTokens.colorPanel(), AcmeTokens.colorPanel()],
    ),
  ],
  gradientInsets: const [1, 1],
);

RemixBoxEffectLayerMix _acmeCardSurfaceStroke(Color color) =>
    RemixBoxEffectLayerMix(
      shadows: [
        RemixBoxShadowMix(color: color, spreadRadius: 1, shapeInset: 1),
      ],
    );
